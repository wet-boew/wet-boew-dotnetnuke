﻿Imports System.IO
Imports DotNetNuke.Entities.Modules

Partial Class DesktopModules_PWGSC_Video_Video
    Inherits DotNetNuke.Entities.Modules.PortalModuleBase

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Try
            btnUpdateSettings.Visible = IsEditable
            btnToggleComments.Visible = IsEditable
            pnlAdmin.ToolTip = Localization.GetString("titleSettings.Text", Me.LocalResourceFile)
            pnlTerms.ToolTip = Localization.GetString("lblTerms.Text", Me.LocalResourceFile)

            If Page.IsPostBack = False Then
                Dim DirRoot As DirectoryInfo
                DirRoot = New DirectoryInfo(Server.MapPath("~/Portals/" & PortalId))

                ddlVideos.Items.Clear()
                ddlFolders.Items.Clear()
                ddlFiles.Items.Clear()

                ddlFolders.Items.Add(New ListItem("<Portal Root>", ""))
                CheckDirectories(DirRoot)
                GetFiles(DirRoot)

                Dim objModules As New DotNetNuke.Entities.Modules.ModuleController
                objModules.GetModuleSettings(ModuleId)

                Dim hash As Hashtable = objModules.GetModuleSettings(ModuleId)

                If String.IsNullOrEmpty(hash("ShowComments")) = False Then
                    pnlComments.Visible = hash("ShowComments")
                End If

                If String.IsNullOrEmpty(hash("FileName")) = False Then
                    ddlFolders.SelectedValue = hash("FolderName").ToString
                    DirRoot = New DirectoryInfo(Server.MapPath("~/Portals/" & PortalId & ddlFolders.SelectedValue))
                    GetFiles(DirRoot)

                    If IsEditable Then
                        ddlFiles.SelectedValue = hash("FileName").ToString
                    End If

                    If hash("FolderOrFile").ToString = "Folder" Then
                        ddlVideos.Visible = True
                        hdnFolder.Text = "/Portals/" & PortalId & "/" & hash("FolderName").ToString
                        LoadVideoList(DirRoot)
                        ShowOneVideo("/Portals/" & PortalId & "/" & hash("FolderName").ToString & ddlVideos.SelectedValue)
                    Else
                        ddlVideos.Visible = False
                        ShowOneVideo("/Portals/" & PortalId & "/" & hash("FolderName").ToString & "/" & hash("FileName").ToString)
                    End If

                End If

            End If

        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        End Try
    End Sub

    Protected Sub AddMessage(ByVal Message As String, ByVal Type As String)
        If Type = "Error" Then
            If UserInfo.IsSuperUser Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("msgError.Text", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If
        ElseIf Type = "Success" Then
            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Message, Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
        ElseIf Type = "Warning" Then
            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Message, Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
        ElseIf Type = "Information" Then
            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Message, Skins.Controls.ModuleMessage.ModuleMessageType.BlueInfo)
        End If
    End Sub

    Protected Sub ShowOneVideo(ByVal VideoPath As String)
        VideoPath = VideoPath.Replace("\", "/").Replace("//", "/") 'Quick fix for url problems
        hdnVideoID.Text = VideoPath

        'Get Video Features
        Dim Title As String
        If ddlVideos.Visible Then
            Title = ddlVideos.SelectedItem.Text
        Else
            Title = VideoPath.Substring(VideoPath.LastIndexOf("/") + 2)
        End If

        Dim Poster As String = ""
        If File.Exists(Server.MapPath(VideoPath.Replace("'", "%27").Substring(0, VideoPath.LastIndexOf(".")) & "-poster.jpg")) Then
            Poster = "poster='" & VideoPath.Replace("'", "%27").Substring(0, VideoPath.LastIndexOf(".")) & "-poster.jpg'"
        End If

        Dim Transcript As String = ""
        If File.Exists(Server.MapPath(VideoPath.Replace("'", "%27").Substring(0, VideoPath.LastIndexOf(".")) & "-transcript.html")) Then
            Transcript = "<track src='" & VideoPath.Replace("'", "%27").Substring(0, VideoPath.LastIndexOf(".")) & "-transcript.html' data-type='text/html' kind='captions'></track> "
        End If

        Dim mp4Video As String = ""
        Dim webmVideo As String = ""
        If File.Exists(Server.MapPath(VideoPath.Replace("'", "%27").ToLower.Replace(".webm", ".mp4"))) Then
            mp4Video = "<source type='video/mp4' src='" & VideoPath.Replace("'", "%27").ToLower.Replace(".webm", ".mp4") & "'></source> "
        End If
        If File.Exists(Server.MapPath(VideoPath.Replace("'", "%27").ToLower.Replace(".mp4", ".web4"))) Then
            webmVideo = "<source type='video/webm' src='" & VideoPath.Replace("'", "%27").ToLower.Replace(".mp4", ".web4") & "'></source> "
        End If

        'Get Video Size
        Dim VideoSize As Integer = 3
        Dim LeftFiller As Integer = 0
        Dim MC As New ModuleController
        If ModuleConfiguration.PaneName = "ContentPane" Then
            Dim HasLeftPane As Boolean = False
            Dim HasRightPane As Boolean = False

            For Each PageMod As ModuleInfo In MC.GetTabModules(PortalSettings.ActiveTab.TabID).Values
                If PageMod.IsDeleted = False Then
                    If PageMod.PaneName = "LeftPane" Then
                        HasLeftPane = True
                    ElseIf PageMod.PaneName = "RightPane" Then
                        HasRightPane = True
                    End If
                End If
            Next

            If HasLeftPane And HasRightPane Then
                VideoSize = 6
            ElseIf HasLeftPane Or HasRightPane Then
                VideoSize = 7
                LeftFiller = 1
            Else
                VideoSize = 10
                LeftFiller = 1
            End If
        ElseIf ModuleConfiguration.PaneName = "MediaPane" Then
            VideoSize = 10
            LeftFiller = 1
        End If

        Dim LeftDiv As String = ""
        If LeftFiller > 0 Then
            LeftDiv = "<div class='row-start span-" & LeftFiller & "'>&nbsp;</div>"
        End If

        lblVideos.Text = LeftDiv & "<div class='wet-boew-multimedia span-" & VideoSize & "' data-load='multimedia' > " & _
                             "<video width='" & (VideoSize * 120) & "' height='" & (VideoSize * 67.5) & "' title='" & Title & "' " & Poster & " > " & _
                                     mp4Video & _
                                     webmVideo & _
                                     Transcript & _
                                     Localization.GetString("msgNoVideo.Text", Me.LocalResourceFile) & _
                             "</video> " & _
                         "</div>"
        LoadComments()
    End Sub

    Private Sub CheckDirectories(ByVal DirRoot As DirectoryInfo)
        Dim strFileSize As String = ""
        Dim DirList As DirectoryInfo() = DirRoot.GetDirectories("*.*")
        Dim RootDir As String = Server.MapPath("~/Portals/" & PortalId)
        For Each DirectoryName As DirectoryInfo In DirList
            ddlFolders.Items.Add(New ListItem(DirectoryName.FullName.Replace(RootDir & "\", ""), DirectoryName.FullName.Replace(RootDir, "")))
            If DirectoryName.FullName.ToLower.Contains("users") Or DirectoryName.FullName.ToLower.Contains("cache") Then
            Else
                CheckDirectories(DirectoryName)
            End If
        Next
    End Sub

    Private Sub GetFiles(Dir As DirectoryInfo)
        ddlFiles.Items.Clear()
        Dim fi As IO.FileInfo
        Dim aryFi As IO.FileInfo() = Dir.GetFiles()
        For Each fi In aryFi
            If fi.Extension.ToLower = ".mp4" Or fi.Extension.ToLower = ".ogg" Or fi.Extension.ToLower = ".webm" Or fi.Extension.ToLower = ".flv" Or fi.Extension.ToLower = ".mp3" Then
                ddlFiles.Items.Add(New ListItem(fi.FullName.Substring(0, fi.FullName.LastIndexOf(".")).Replace(Dir.FullName & "\", ""), fi.FullName.Replace(Dir.FullName, "")))
            End If
        Next

        'Hide/Show button
        If ddlFiles.Items.Count = 0 Then
            btnFiles.Visible = False
            btnFolder.Visible = False
        Else
            btnFiles.Visible = True
            btnFolder.Visible = True
        End If
    End Sub

    'This may seem silly to duplicate the same search, but it was causing problems in the update panel when both were together
    Private Sub LoadVideoList(Dir As DirectoryInfo)
        ddlVideos.Items.Clear()
        Dim fi As IO.FileInfo
        Dim aryFi As IO.FileInfo() = Dir.GetFiles()
        For Each fi In aryFi
            If fi.Extension.ToLower = ".mp4" Or fi.Extension.ToLower = ".ogg" Or fi.Extension.ToLower = ".webm" Or fi.Extension.ToLower = ".flv" Or fi.Extension.ToLower = ".mp3" Then
                ddlVideos.Items.Add(New ListItem(fi.FullName.Substring(0, fi.FullName.LastIndexOf(".")).Replace(Dir.FullName & "\", ""), fi.FullName.Replace(Dir.FullName, "")))
            End If
        Next
        If System.Globalization.CultureInfo.CurrentUICulture.Name.Contains("fr") Then
            If ddlVideos.SelectedValue.Contains("\English") Then ddlVideos.SelectedIndex = 1
        End If
    End Sub

    Protected Sub btnFolder_Click(sender As Object, e As System.EventArgs) Handles btnFolder.Click
        Dim objModules As New DotNetNuke.Entities.Modules.ModuleController
        objModules.UpdateModuleSetting(ModuleId, "FolderOrFile", "Folder")
        objModules.UpdateModuleSetting(ModuleId, "FolderName", ddlFolders.SelectedValue)
        objModules.UpdateModuleSetting(ModuleId, "FileName", ddlFiles.SelectedValue)
        Response.Redirect(NavigateURL(TabId))
    End Sub

    Protected Sub btnFiles_Click(sender As Object, e As System.EventArgs) Handles btnFiles.Click
        Dim objModules As New DotNetNuke.Entities.Modules.ModuleController
        objModules.UpdateModuleSetting(ModuleId, "FolderOrFile", "File")
        objModules.UpdateModuleSetting(ModuleId, "FolderName", ddlFolders.SelectedValue)
        objModules.UpdateModuleSetting(ModuleId, "FileName", ddlFiles.SelectedValue)
        Response.Redirect(NavigateURL(TabId))
    End Sub

    Protected Sub ddlVideos_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlVideos.SelectedIndexChanged
        lblVideos.Text = ""
        ShowOneVideo(hdnFolder.Text & ddlVideos.SelectedValue)
    End Sub

    Protected Sub LoadComments()
        Dim ConnString As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
        ConnString.Open()

        Dim PWGSCDataset As New DataSet
        Dim PWGSCCommand As New SqlCommand
        PWGSCCommand.CommandText = "SELECT ID, ModuleID, REPLACE(Comment,CHAR(13),'<br />') AS Comment, CommentBy, CAST(DateSubmitted AS VARCHAR(50)) AS 'DateSubmitted' FROM Comments WHERE ModuleID = @ModuleID AND OtherID = @OtherID"
        PWGSCCommand.Parameters.AddWithValue("@ModuleID", ModuleId)
        PWGSCCommand.Parameters.AddWithValue("@OtherID", hdnVideoID.Text)
        PWGSCCommand.Connection = ConnString
        Try
            lstComments.DataSource = PWGSCCommand.ExecuteReader
            lstComments.DataBind()
        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        Finally
            ConnString.Close()
        End Try
    End Sub

    Protected Sub btnAdd_Click(sender As Object, e As System.EventArgs) Handles btnAdd.Click
        Dim ValidGovEmail As Boolean = False
        If txtCommentBy.Text.ToLower.EndsWith(".gc.ca") Then
            ValidGovEmail = True
        Else
            AddMessage(Localization.GetString("msgNotGovernment.Text", Me.LocalResourceFile), "Warning")
        End If

        If String.IsNullOrEmpty(txtComment.Text) = False And String.IsNullOrEmpty(txtCommentBy.Text) = False And ValidGovEmail Then
            Dim ConnString As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
            ConnString.Open()

            Dim PWGSCDataset As New DataSet
            Dim PWGSCCommand As New SqlCommand
            PWGSCCommand.CommandText = "INSERT INTO Comments(ModuleID, Comment, CommentBy, DateSubmitted, OtherID) VALUES(@ModuleID, @Comment, @CommentBy, GETDATE(), @OtherID)"
            PWGSCCommand.Parameters.AddWithValue("@ModuleID", ModuleId)
            PWGSCCommand.Parameters.AddWithValue("@Comment", txtComment.Text)
            PWGSCCommand.Parameters.AddWithValue("@CommentBy", txtCommentBy.Text)
            PWGSCCommand.Parameters.AddWithValue("@OtherID", hdnVideoID.Text)
            PWGSCCommand.Connection = ConnString
            Try
                PWGSCCommand.ExecuteNonQuery()
                DotNetNuke.Services.Mail.Mail.SendMail(PortalSettings.Email, PortalSettings.Email, "", "New Comment Posted", Request.Url.AbsoluteUri & "<br /><br />" & ModuleConfiguration.ModuleTitle & "<br /><br />" & txtCommentBy.Text & "<br /><br />" & txtComment.Text, "", "HTML", "", "", "", "")
            Catch ex As Exception
                AddMessage(ex.Message, "Error")
                DotNetNuke.Services.Exceptions.LogException(ex)
            Finally
                ConnString.Close()
            End Try
            LoadComments()
        End If
    End Sub

    Protected Sub ddlFolders_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlFolders.SelectedIndexChanged
        Dim DirRoot As DirectoryInfo
        DirRoot = New DirectoryInfo(Server.MapPath("~/Portals/" & PortalId & ddlFolders.SelectedValue))
        GetFiles(DirRoot)
    End Sub

    Protected Sub lstComments_ItemDeleting(sender As Object, e As System.Web.UI.WebControls.ListViewDeleteEventArgs) Handles lstComments.ItemDeleting
        Dim ConnString As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
        ConnString.Open()

        Dim PWGSCDataset As New DataSet
        Dim PWGSCCommand As New SqlCommand
        PWGSCCommand.CommandText = "DELETE FROM Comments WHERE ID = @ID"
        Try
            PWGSCCommand.Parameters.AddWithValue("@ID", CType(lstComments.Items(e.ItemIndex).FindControl("lblID"), Label).Text)
            PWGSCCommand.Connection = ConnString
            PWGSCCommand.ExecuteNonQuery()
        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        Finally
            ConnString.Close()
        End Try
        LoadComments()
    End Sub

    Protected Sub btnToggleComments_Click(sender As Object, e As System.EventArgs) Handles btnToggleComments.Click
        Dim modController As New ModuleController
        If pnlComments.Visible Then
            pnlComments.Visible = False
        Else
            pnlComments.Visible = True
        End If
        modController.UpdateModuleSetting(ModuleId, "ShowComments", pnlComments.Visible)
    End Sub
End Class
