﻿Imports DotNetNuke
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Security
Imports DotNetNuke.Entities.Users
Imports System.Data.Sql
Imports System.Data.SqlClient
Partial Class DesktopModules_WET_SlideShow_SlideShow
    Inherits DotNetNuke.Entities.Modules.PortalModuleBase
    Implements Entities.Modules.IActionable

    Dim LangController As New LocaleController
    Dim HasLeftPane As Boolean = False
    Dim HasRightPane As Boolean = False
    Dim Style As String = ""

    Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
        Get
            Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
            Actions.Add(GetNextActionID, Localization.GetString("AddSlide", LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", _
            EditUrl("AddSlide"), False, SecurityAccessLevel.Edit, True, False)
            Return Actions
        End Get
    End Property

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Dim MC As New ModuleController

        Try
            'Get Size
            Dim SpanLeft As String = "3"
            Dim SpanRight As String = "9"

            If ModuleConfiguration.PaneName = "LeftPane" Or ModuleConfiguration.PaneName = "RightPane" Then
                SpanLeft = "1"
                SpanRight = "2"
            ElseIf ModuleConfiguration.PaneName = "ContentPane" Then
                Dim HasLeftPane As Boolean = False
                Dim HasRightPane As Boolean = False

                For Each PageMod As ModuleInfo In MC.GetTabModules(PortalSettings.ActiveTab.TabID).Values
                    If PageMod.IsDeleted = False Then
                        If PageMod.PaneName = "LeftPane" Then
                            HasLeftPane = True
                        ElseIf PageMod.PaneName = "RightPane" Then
                            HasRightPane = True
                        End If
                    End If
                Next

                If HasLeftPane And HasRightPane Then
                    SpanLeft = "2"
                    SpanRight = "4"
                ElseIf HasLeftPane Or HasRightPane Then
                    SpanLeft = "3"
                    SpanRight = "6"
                End If

            End If

            'Get Images
            Using Connection As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
                Dim tabsPanelStr As String = ""
                Dim tabsStr As String = ""
                Dim command As New SqlCommand
                command.CommandText = "SELECT * FROM SlideShow WHERE ModuleID = @ModuleID Order By SlideNumber"
                command.Parameters.AddWithValue("@ModuleID", ModuleId)
                command.Connection = Connection
                Try
                    command.Connection.Open()
                    Dim reader As SqlDataReader = command.ExecuteReader
                    Dim SlideNum As Integer = 1
                    While reader.Read
                        If reader.Item("visible") = "True" Then

                            Dim fr As String = ""
                            If LangController.GetCurrentLocale(PortalSettings.PortalId).Code.ToLower.Contains("fr") Then
                                fr = "Fr"
                            End If

                            tabsPanelStr = tabsPanelStr & "<div id='tab" & SlideNum & "' class='panel' ><section>" & _
                                    "<div class='float-left slide-text span-" & SpanLeft & " row-start' ><div class='tabs-content-pad'><p class='font-xlarge margin-top-none'>" & reader.Item("title" & fr) & "</p><p>" & reader.Item("description" & fr) & "</p><p><a href='" & reader.Item("link" & fr) & "' target='_blank' class='button button-accent'>" & Localization.GetString("Continue", LocalResourceFile) & "</a></p></div></div>" & _
                                    "<div class='float-right slide-image span-" & SpanRight & " row-end' ><img style='height:250px;' class='float-right' src='" & reader.Item("photo" & fr).Replace("\", "/").Replace("~", "") & "' alt='" & reader.Item("description" & fr) & "' /></div>" & _
                                    "<div class='clear'></div></section></div>"

                            tabsStr = tabsStr & "<li><a href='#tab" & SlideNum & "'>" & SlideNum & "</a></li>"

                            SlideNum = SlideNum + 1
                        End If
                    End While

                    tabsMenu.Text = tabsStr
                    tabsPanel.Text = tabsPanelStr

                Finally
                    command.Connection.Close()
                End Try
            End Using
        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
    End Sub
End Class






