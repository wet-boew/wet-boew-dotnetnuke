﻿Imports DotNetNuke
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Security
Imports DotNetNuke.Entities.Users
Imports System.Data.Sql
Imports System.Data.SqlClient
Partial Class DesktopModules_WET_Gallery_Gallery
    Inherits DotNetNuke.Entities.Modules.PortalModuleBase
    Implements Entities.Modules.IActionable

    Dim LangController As New LocaleController
    Dim HasLeftPane As Boolean = False
    Dim HasRightPane As Boolean = False
    Dim Style As String = ""

    Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
        Get
            Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
            Actions.Add(GetNextActionID, Localization.GetString("AddPhoto", LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", _
            EditUrl("AddPhoto"), False, SecurityAccessLevel.Edit, True, False)
            Return Actions
        End Get
    End Property

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Try
            'Get Images
            Using Connection As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
                Dim tabsStr As String = ""
                Dim command As New SqlCommand
                command.CommandText = "SELECT * FROM Gallery WHERE moduleID = @ModuleID ORDER BY ID"
                command.Parameters.AddWithValue("@ModuleID", ModuleId)
                command.Connection = Connection
                Dim ItemCount As Integer = 0
                Try
                    command.Connection.Open()
                    Dim reader As SqlDataReader = command.ExecuteReader
                    While reader.Read
                        ItemCount = ItemCount + 1
                        Dim fr As String = ""
                        If LangController.GetCurrentLocale(PortalSettings.PortalId).Code.ToLower.Contains("fr") Then
                            fr = "Fr"
                        End If
                        tabsStr = tabsStr & "<li><a class='lb-item-gal' href='" & reader.Item("photo" & fr).Replace("\", "/").Replace("~", "") & "' title='<b>" & reader.Item("title" & fr) & ":</b> " & reader.Item("description" & fr) & "'><img style='height:150px;' src='" & reader.Item("photo" & fr).Replace("\", "/").Replace("~", "") & "' alt='Alt text for the image' class='image-actual' /></a></li>"
                    End While
                    tabsMenu.Text = tabsStr
                Finally
                    command.Connection.Close()
                End Try

                If ModuleConfiguration.PaneName.ToUpper.Contains("RIGHT") Or ModuleConfiguration.PaneName.ToUpper.Contains("LEFT") Then
                Else
                    If ItemCount = 1 Then
                        tabsMenu.Text = tabsMenu.Text.Replace("<li>", "<li class='width-90'>").Replace("height:150px;", "max-width:100%; max-height:250px;")
                    ElseIf ItemCount = 2 Then
                        tabsMenu.Text = tabsMenu.Text.Replace("<li>", "<li class='width-40'>")
                    ElseIf ItemCount > 5 And ItemCount < 10 Then
                        tabsMenu.Text = tabsMenu.Text.Replace("<li>", "<li class='span-4'>")
                    ElseIf ItemCount >= 10 And ItemCount < 15 Then
                        tabsMenu.Text = tabsMenu.Text.Replace("<li>", "<li class='span-3'>")
                    ElseIf ItemCount >= 15 Then
                        tabsMenu.Text = tabsMenu.Text.Replace("<li>", "<li class='span-2'>")
                    End If
                End If
            End Using
        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
    End Sub
End Class






