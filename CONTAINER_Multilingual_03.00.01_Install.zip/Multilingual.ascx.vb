﻿Imports DotNetNuke.Entities.Modules.Actions
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.Entities.Modules

Partial Class Portals__default_Containers_CLF___DNN_6_Multilingual
    Inherits DotNetNuke.UI.Containers.Container

    Dim LangController As New LocaleController
    Dim ModController As New ModuleController
    Dim TabController As New TabController
    Dim TabPermController As New DotNetNuke.Security.Permissions.TabPermissionController

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        LoadSettings()
        SetLanguage()
        HideExtraAdminButtons()
        LoadTabListForUser()

        'For things like the login module
        If ModuleConfiguration.ModuleID = "-1" Then
            pnlTitle.Visible = False
            pnlTitleH1.Visible = False
        End If
    End Sub

    Protected Sub LoadTabListForUser()
        Try
            'ToDo Later
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub LoadSettings()
        Try
            Dim ModID As Integer = ModuleConfiguration.ModuleID
            Dim ThisMod As ModuleInfo = ModController.GetModule(ModID)
            Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name

            'Multilingual
            If LangController.GetDefaultLocale(PortalSettings.PortalId).Code = ThisLocale Then
                'Use the default site settings
                lblTitle.Text = ThisMod.ModuleTitle
                txtModuleTitle.Text = ThisMod.ModuleTitle
            Else
                'Use the module settings to store the values
                Dim hash As Hashtable = ModController.GetModuleSettings(ModuleConfiguration.ModuleID)
                If String.IsNullOrEmpty(hash("ModuleTitle" & ThisLocale)) Then
                    lblTitle.Text = ThisMod.ModuleTitle
                    txtModuleTitle.Text = ThisMod.ModuleTitle
                Else
                    lblTitle.Text = hash("ModuleTitle" & ThisLocale).ToString
                    txtModuleTitle.Text = hash("ModuleTitle" & ThisLocale).ToString
                End If
            End If

            lblTitleH1.Text = lblTitle.Text

            'Hide buttons on page load, and check the checkboxes
            cbxPrint.Checked = ThisMod.DisplayPrint
            If ThisMod.DisplayPrint Then
                btnPrint.Attributes.CssStyle.Add("display", "inline")
                btnPrintH1.Attributes.CssStyle.Add("display", "inline")
            Else
                btnPrint.Attributes.CssStyle.Add("display", "none")
                btnPrintH1.Attributes.CssStyle.Add("display", "none")
            End If
            cbxShowTitle.Checked = ThisMod.DisplayTitle
            If ThisMod.DisplayTitle Then
                pnlTitle.Attributes.CssStyle.Add("display", "inline")
                pnlTitleH1.Attributes.CssStyle.Add("display", "inline")
            Else
                pnlTitle.Attributes.CssStyle.Add("display", "none")
                pnlTitleH1.Attributes.CssStyle.Add("display", "none")
            End If

            'Checks if it's in the media pane, use the H1 title            
            If ModuleConfiguration.PaneName.ToUpper = "MEDIAPANE" Then
                pnlTitleH1.Visible = True
                pnlTitle.Visible = False
                If ThisMod.DisplayTitle = False Then
                    pnlTitleH1.Visible = IsEditMode()
                End If
            Else
                pnlTitle.Visible = True
                pnlTitleH1.Visible = False
                If ThisMod.DisplayTitle = False Then
                    pnlTitle.Visible = IsEditMode()
                End If
            End If

            cbxVisible.Checked = ThisMod.InheritViewPermissions

            If ThisMod.InheritViewPermissions Or IsEditMode() = False Then
                btnVisible.Attributes.CssStyle.Add("display", "none")
                btnVisibleH1.Attributes.CssStyle.Add("display", "none")
            Else
                btnVisible.Attributes.CssStyle.Add("display", "inline")
                btnVisibleH1.Attributes.CssStyle.Add("display", "inline")
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub HideExtraAdminButtons()
        Try
            If PortalSettings.UserInfo.IsSuperUser = False Then
                'Each top level action group
                Dim count As Integer = dnnACTIONS.MenuActions.Count
                Dim UnneededActions() As String = {"Actualiser", "Aide en ligne", "Aide", "Importation de contenu", "Exportation de contenu", "My Work", "Export Content", "Import Content", "Help", "Online Help", "View Source", "Refresh", ""}
                While 0 < count

                    count = count - 1

                    'Each action in the group
                    Dim actions As Integer = dnnACTIONS.MenuActions(count).Actions.Count
                    While 0 < actions
                        actions = actions - 1
                        'Removes values we don't want
                        Dim title As String = dnnACTIONS.MenuActions(count).Actions(actions).Title
                        For Each item As String In UnneededActions
                            If item = title.Trim Then
                                dnnACTIONS.MenuActions(count).Actions.RemoveAt(actions)
                            End If
                        Next
                    End While

                End While
            End If

            'Add the new "basic settings" option
            Dim BasicActions As ModuleAction = New ModuleAction(0 & ModuleConfiguration.ModuleID, lblBasic.Text, "pwgscbasic")
            Dim jsAction As New ModuleAction(1 & ModuleConfiguration.ModuleID)
            With jsAction
                .Title = lblSettings.Text
                .CommandName = ModuleActionType.EditContent
                '.ClientScript = "LoadBasic" & ModuleConfiguration.ModuleID & "()"
                .Url = "javascript:LoadBasic" & ModuleConfiguration.ModuleID & "()"
                .Secure = DotNetNuke.Security.SecurityAccessLevel.Edit
                .Icon = "/images/action_settings.gif"
            End With
            BasicActions.Actions.Add(jsAction)

            dnnACTIONS.MenuActions.Insert(0, BasicActions) 'DNN 6
        Catch ex As Exception
        End Try
    End Sub

    Protected Sub SetLanguage()
        cbxPrint.Text = Localization.GetString("MODULEShowPrint", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        cbxShowTitle.Text = Localization.GetString("MODULETitle", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        cbxVisible.Text = Localization.GetString("MODULEVisible", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnSave.Text = Localization.GetString("MODULESave", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        pnlSettings.ToolTip = "<div style='width:650px; float:left;'>" & Localization.GetString("MODULEBasic", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc))) & "</div>"
        lblBasic.Text = Localization.GetString("MODULEGeneral", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblSettings.Text = Localization.GetString("MODULEBasic", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnPrint.ToolTip = Localization.GetString("MODULEPrint", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnVisible.ToolTip = Localization.GetString("MODULELimited", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnPrint.AlternateText = Localization.GetString("MODULEPrint", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnVisible.AlternateText = Localization.GetString("MODULELimited", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnPrintH1.ToolTip = Localization.GetString("MODULEPrint", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnVisibleH1.ToolTip = Localization.GetString("MODULELimited", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnPrintH1.AlternateText = Localization.GetString("MODULEPrint", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnVisibleH1.AlternateText = Localization.GetString("MODULELimited", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
    End Sub

    Protected Sub btnPrint_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs) Handles btnPrint.Click
        Response.Redirect("/Default.aspx?tabid=" & ModuleConfiguration.TabID & "&mid=" & ModuleConfiguration.ModuleID & "&dnnprintmode=true&SkinSrc=[G]Skins%2f_default%2fNo+Skin&ContainerSrc=[G]Containers%2f_default%2fNo+Container")
    End Sub
End Class
