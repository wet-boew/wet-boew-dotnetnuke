﻿
Partial Class DesktopModules_PWGSC_Comments_Comments
    Inherits DotNetNuke.Entities.Modules.PortalModuleBase

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        pnlTerms.ToolTip = Localization.GetString("lblTerms.Text", Me.LocalResourceFile)
        LoadComments()
        txtCommentBy.Text = UserInfo.DisplayName
        pnlLoggedin.Visible = Request.IsAuthenticated
    End Sub


    Protected Sub AddMessage(ByVal Message As String, ByVal Type As String)
        If Type = "Error" Then
            If UserInfo.IsSuperUser Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("msgError.Text", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If
        ElseIf Type = "Success" Then
            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Message, Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
        ElseIf Type = "Warning" Then
            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Message, Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
        ElseIf Type = "Information" Then
            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Message, Skins.Controls.ModuleMessage.ModuleMessageType.BlueInfo)
        End If
    End Sub


    Protected Sub LoadComments()
        Dim ConnString As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
        ConnString.Open()

        Dim WETCommand As New SqlCommand
        WETCommand.CommandText = "SELECT ID, ModuleID, REPLACE(Comment,CHAR(13),'<br />') AS Comment, CommentBy, CAST(DateSubmitted AS VARCHAR(50)) AS 'DateSubmitted' FROM Comments WHERE ModuleID = @ModuleID"
        WETCommand.Parameters.AddWithValue("@ModuleID", ModuleId)
        WETCommand.Connection = ConnString
        Try
            lstComments.DataSource = WETCommand.ExecuteReader
            lstComments.DataBind()
        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        Finally
            ConnString.Close()
        End Try
    End Sub

    Protected Sub btnAdd_Click(sender As Object, e As System.EventArgs) Handles btnAdd.Click
        If String.IsNullOrEmpty(txtComment.Text) = False And String.IsNullOrEmpty(txtCommentBy.Text) = False Then
            Dim ConnString As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
            ConnString.Open()

            Dim WETCommand As New SqlCommand
            WETCommand.CommandText = "INSERT INTO Comments(ModuleID, Comment, CommentBy, DateSubmitted) VALUES(@ModuleID, @Comment, @CommentBy, GETDATE())"
            WETCommand.Parameters.AddWithValue("@ModuleID", ModuleId)
            WETCommand.Parameters.AddWithValue("@Comment", HttpUtility.HtmlEncode(txtComment.Text))
            WETCommand.Parameters.AddWithValue("@CommentBy", txtCommentBy.Text)
            WETCommand.Connection = ConnString
            Try
                WETCommand.ExecuteNonQuery()
                DotNetNuke.Services.Mail.Mail.SendMail(PortalSettings.Email, PortalSettings.Email, "", Localization.GetString("msgSubject.Text", Me.LocalResourceFile), Request.Url.AbsoluteUri.ToLower.Replace(System.Globalization.CultureInfo.CurrentUICulture.Name.ToLower + "/", "") & "<br /><br />" & ModuleConfiguration.ModuleTitle & "<br /><br />" & txtCommentBy.Text & "<br /><br />" & txtComment.Text, "", "HTML", "", "", "", "")
            Catch ex As Exception
                AddMessage(ex.Message, "Error")
                DotNetNuke.Services.Exceptions.LogException(ex)
            Finally
                ConnString.Close()
            End Try
            LoadComments()
        End If
    End Sub

    Protected Sub lstComments_ItemDeleting(sender As Object, e As System.Web.UI.WebControls.ListViewDeleteEventArgs) Handles lstComments.ItemDeleting
        Dim ConnString As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
        ConnString.Open()

        Dim WETCommand As New SqlCommand
        WETCommand.CommandText = "DELETE FROM Comments WHERE ID = @ID"
        Try
            WETCommand.Parameters.AddWithValue("@ID", CType(lstComments.Items(e.ItemIndex).FindControl("lblID"), Label).Text)
            WETCommand.Connection = ConnString
            WETCommand.ExecuteNonQuery()
        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        Finally
            ConnString.Close()
        End Try
        LoadComments()
    End Sub
End Class
