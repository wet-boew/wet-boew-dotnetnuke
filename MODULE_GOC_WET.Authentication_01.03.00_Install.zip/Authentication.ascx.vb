﻿Imports DotNetNuke.Security.Membership
Imports System.Net
Imports DotNetNuke.Services.Authentication
Imports DotNetNuke.Security.Roles
Imports DotNetNuke.Entities.Users

Partial Class DesktopModules_WET_Authentication_Authentication
    Inherits DotNetNuke.Entities.Modules.PortalModuleBase

    Protected Sub btnLogin_Click(sender As Object, e As System.EventArgs) Handles btnLogin.Click
        Try
            Dim Valid As Boolean = True
            If String.IsNullOrEmpty(txtUserName.Text) Or String.IsNullOrEmpty(txtPassword.Text) Then
                Valid = False
            End If

            If Valid Then
                Login(txtUserName.Text, txtPassword.Text)
            Else
                AddMessage(Localization.GetString("msgValidate.Text", Me.LocalResourceFile), "Warning")
            End If
        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        End Try

    End Sub

    Protected Sub AddMessage(ByVal Message As String, ByVal Type As String)
        If Type = "Error" Then
            If UserInfo.IsSuperUser Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("msgError.Text", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If
        ElseIf Type = "Success" Then
            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Message, Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
        ElseIf Type = "Warning" Then
            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Message, Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
        ElseIf Type = "Information" Then
            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Message, Skins.Controls.ModuleMessage.ModuleMessageType.BlueInfo)
        End If
    End Sub

    Protected Sub Login(ByVal MyUserName As String, ByVal MyPassword As String)
        Dim loginStatus As New UserLoginStatus()
        Dim Login As Boolean = False

        'Do AD Login first
        If cbxAgree.Checked Then
            If ValidateADUser(MyUserName, MyPassword) Then
                SyncUser(MyUserName)
                Dim ThisUser As UserInfo = UserController.GetUserByName(PortalId, MyUserName)
                UserController.UserLogin(PortalId, ThisUser, PortalSettings.PortalName, Request.UserHostAddress, cbxLogin.Checked)
                Login = True
            Else
                'Regular login
                Dim objUser As UserInfo = UserController.ValidateUser(0, MyUserName, MyPassword, "", "", Request.UserHostAddress, loginStatus)

                If loginStatus = UserLoginStatus.LOGIN_SUCCESS Or loginStatus = UserLoginStatus.LOGIN_SUPERUSER Then
                    If Request.IsAuthenticated Then FormsAuthentication.SignOut()

                    UserController.UserLogin(Me.PortalId, objUser, PortalSettings.PortalName, Request.UserHostAddress, cbxLogin.Checked)
                    Login = True
                End If
            End If

            'Login result
            If Login Then
                If Request.QueryString("returnurl") Is Nothing = False Then
                    Response.Redirect(Request.QueryString("returnurl").ToString.ToLower.Replace(System.Globalization.CultureInfo.CurrentUICulture.Name.ToLower + "/", ""))
                Else
                    Response.Redirect(NavigateURL(GetPortalSettings.HomeTabId).ToLower.Replace(System.Globalization.CultureInfo.CurrentUICulture.Name.ToLower + "/", ""))
                End If
            Else
                AddMessage(Localization.GetString("msgFailedLogin.Text", Me.LocalResourceFile), "Warning")
            End If
        Else
            AddMessage(Localization.GetString("msgValidate.Text", Me.LocalResourceFile), "Warning")
        End If
    End Sub

    Protected Sub btnSendNewPassword_Click(sender As Object, e As System.EventArgs) Handles btnSendNewPassword.Click
        Try
            If String.IsNullOrEmpty(txtForgotPassword.Text) = False Then
                Dim Count As Integer = 0
                For Each user As UserInfo In UserController.GetUsersByEmail(PortalId, txtForgotPassword.Text, 0, 100, 10)
                    Count = Count + 1
                    user.Membership.Password = UserController.GetPassword(user, "")
                    DotNetNuke.Services.Mail.Mail.SendMail(user, DotNetNuke.Services.Mail.MessageType.PasswordReminder, Me.PortalSettings)
                    If Count <= 1 Then
                        AddMessage(Localization.GetString("msgPasswordSent.Text", Me.LocalResourceFile), "Success")
                    End If
                Next
                If Count = 0 Then
                    AddMessage(Localization.GetString("msgNoneFound.Text", Me.LocalResourceFile), "Warning")
                End If
            End If
        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        End Try
    End Sub

    Public Function ValidateADUser(ByVal Username As String, ByVal Password As String) As Boolean
        'Find valid user in Active Directory
        Dim Success As Boolean = False

        'Check if LDAP exists in the web.config

        Dim LDAPString As String = ""

        If System.Configuration.ConfigurationManager.AppSettings("LDAP") Is Nothing = False Then
            LDAPString = System.Configuration.ConfigurationManager.AppSettings("LDAP").ToString & "DC=ad,DC=pwgsc-tpsgc,DC=gc,DC=ca"
        Else
            Dim ModController As New DotNetNuke.Entities.Modules.ModuleController
            Dim hash As Hashtable = ModController.GetModuleSettings(ModuleId)
            If String.IsNullOrEmpty(hash("LDAP")) = False Then
                LDAPString = hash("LDAP")
            End If
        End If

        If LDAPString <> "" Then
            Dim Entry As New System.DirectoryServices.DirectoryEntry(LDAPString, Username, Password, DirectoryServices.AuthenticationTypes.Secure)

            Dim Searcher As New System.DirectoryServices.DirectorySearcher(Entry)

            Searcher.SearchScope = DirectoryServices.SearchScope.OneLevel
            Try
                Dim Results As System.DirectoryServices.SearchResult = Searcher.FindOne
                Success = Not (Results Is Nothing)
            Catch ex As Exception
                Success = False
            End Try
        End If

        Return Success
    End Function

    Protected Sub CreateNewUser(ByVal FirstName As String, ByVal LastName As String, ByVal UserName As String, ByVal Email As String, ByVal Telephone As String, ByVal Address As String, ByVal City As String, ByVal Province As String, ByVal PostalCode As String, ByVal cell As String, ByVal fax As String, ByVal title As String)
        ' create a new user instance and populate it
        Dim User As New UserInfo
        Dim Password As String = "defaultpass"

        'For province, convert to Shorter
        If Province = "Alberta" Then
            Province = "AB"
        ElseIf Province = "British Columbia" Then
            Province = "BC"
        ElseIf Province = "Manitoba" Then
            Province = "MB"
        ElseIf Province = "New Brunswick" Then
            Province = "NB"
        ElseIf Province = "Newfoundland and Labrador" Then
            Province = "NL"
        ElseIf Province = "Northwest Territories" Then
            Province = "NT"
        ElseIf Province = "Nova Scotia" Then
            Province = "NS"
        ElseIf Province = "Nunavut" Then
            Province = "NU"
        ElseIf Province = "Ontario" Then
            Province = "ON"
        ElseIf Province = "Prince Edward Island" Then
            Province = "PE"
        ElseIf Province = "Quebec" Then
            Province = "QC"
        ElseIf Province = "Saskatchewan" Then
            Province = "SK"
        ElseIf Province = "Yukon Territory" Then
            Province = "YT"
        End If

        With User
            .Profile.InitialiseProfile(PortalId)
            .AffiliateID = -1
            .DisplayName = String.Concat(FirstName, " ", LastName)
            .Email = Email
            .FirstName = FirstName
            .LastName = LastName
            .IsSuperUser = False
            .Membership.Approved = True
            .Membership.CreatedDate = DateTime.Now
            .Membership.Email = Email
            'Will need to store display this password list once for rick
            Password = txtPassword.Text
            .Membership.Password = Password
            .Membership.Username = UserName
            .PortalID = PortalId
            .Username = UserName
            .Profile.FirstName = FirstName
            .Profile.LastName = LastName
            '.Profile.PreferredLocale = PortalSettings.Current.DefaultLanguage
            '.Profile.TimeZone = PortalSettings.Current.TimeZoneOffset
            .Membership.UpdatePassword = False
            .Profile.Telephone = Telephone
            .Profile.Street = Address
            .Profile.City = City
            .Profile.Region = Province
            .Profile.PostalCode = PostalCode
            .Profile.Country = "Canada"
            .Profile.Fax = fax
            .Profile.Cell = cell
        End With

        ' attempt to create the DNN user
        Dim objStatus As UserCreateStatus = UserController.CreateUser(User)

    End Sub

    Protected Sub UpdateUser(ByVal ThisUserID As Integer, ByVal FirstName As String, ByVal LastName As String, ByVal UserName As String, ByVal Email As String, ByVal Telephone As String, ByVal Address As String, ByVal City As String, ByVal Province As String, ByVal PostalCode As String, ByVal cell As String, ByVal fax As String, ByVal title As String)
        ' create a new user instance and populate it
        Dim User As New UserInfo

        'For province, convert to Shorter
        If Province = "Alberta" Then
            Province = "AB"
        ElseIf Province = "British Columbia" Then
            Province = "BC"
        ElseIf Province = "Manitoba" Then
            Province = "MB"
        ElseIf Province = "New Brunswick" Then
            Province = "NB"
        ElseIf Province = "Newfoundland and Labrador" Then
            Province = "NL"
        ElseIf Province = "Northwest Territories" Then
            Province = "NT"
        ElseIf Province = "Nova Scotia" Then
            Province = "NS"
        ElseIf Province = "Nunavut" Then
            Province = "NU"
        ElseIf Province = "Ontario" Then
            Province = "ON"
        ElseIf Province = "Prince Edward Island" Then
            Province = "PE"
        ElseIf Province = "Quebec" Then
            Province = "QC"
        ElseIf Province = "Saskatchewan" Then
            Province = "SK"
        ElseIf Province = "Yukon Territory" Then
            Province = "YT"
        End If

        User = UserController.GetUserById(PortalId, ThisUserID)
        With User
            .DisplayName = String.Concat(FirstName, " ", LastName)
            .Email = Email
            .FirstName = FirstName
            .LastName = LastName
            .Membership.Email = Email
            .Profile.FirstName = FirstName
            .Profile.LastName = LastName
            .Profile.Telephone = Telephone
            .Profile.Street = Address
            .Profile.City = City
            .Profile.Region = Province
            .Profile.PostalCode = PostalCode
            .Profile.Country = "Canada"
            .Profile.Fax = fax
            .Profile.Cell = cell
        End With

        ' attempt to create the DNN user
        UserController.UpdateUser(PortalId, User)

    End Sub


    Public Function DoesEmployeeExist(ByVal username As String) As Integer
        Dim Exists As Integer = 0
        Dim ConnString As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
        ConnString.Open()

        Dim WETCommand As New SqlCommand
        WETCommand.CommandType = CommandType.Text
        WETCommand.CommandText = "SELECT Users.[UserId],UserPortals.IsDeleted FROM [dbo].[Users] INNER JOIN dbo.UserPortals on UserPortals.UserID = Users.UserID WHERE UserName = '" & username & "'"
        WETCommand.Connection = ConnString
        Dim WETReader As SqlDataReader
        WETReader = WETCommand.ExecuteReader
        Try
            If WETReader.HasRows Then
                While WETReader.Read
                    Exists = Integer.Parse(WETReader.Item(0).ToString)
                    If Boolean.Parse(WETReader.Item(1).ToString) = True Then
                        Exists = Exists * -1
                    End If
                End While
            End If
        Finally
            WETReader.Close()
            ConnString.Close()
        End Try
        Return Exists
    End Function

    Public Sub ReactivateUser(ByVal ThisUserID As Integer, ByVal FirstName As String, ByVal LastName As String, ByVal UserName As String, ByVal Email As String, ByVal Telephone As String, ByVal Address As String, ByVal City As String, ByVal Province As String, ByVal PostalCode As String)
        ' create a new user instance and populate it
        Dim User As New UserInfo
        Dim Password As String = "defaultpass"

        'Recreate the user account incase new user
        With User
            .UserID = ThisUserID
            .AffiliateID = -1
            .DisplayName = String.Concat(FirstName, " ", LastName)
            .Email = Email
            .FirstName = FirstName
            .LastName = LastName
            .IsSuperUser = False
            .Membership.Approved = True
            .IsDeleted = False
            .Membership.LockedOut = False
            .Membership.CreatedDate = DateTime.Now
            .Membership.Email = Email
            Password = txtPassword.Text
            .Membership.Password = Password
            .Membership.Username = UserName
            .PortalID = PortalId
            .Username = UserName
            .Profile.FirstName = FirstName
            .Profile.LastName = LastName
            .Membership.UpdatePassword = False
            .Profile.Telephone = Telephone
            .Profile.Street = Address
            .Profile.City = City
            .Profile.Region = Province
            .Profile.PostalCode = PostalCode
            .Profile.Country = "Canada"
        End With

        'Add them as a registered user and subscriber
        Dim this As New RoleController
        this.AddUserRole(PortalId, User.UserID, 1, Today.AddYears(100))
        this.AddUserRole(PortalId, User.UserID, 2, Today.AddYears(100))

        'Remove their roles incase the reactivated user shouldn't have them
        Dim ConnString As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
        ConnString.Open()

        Dim WETCommand As New SqlCommand
        WETCommand.CommandText = "DELETE FROM UserRoles WHERE UserID = " & ThisUserID & " AND (RoleID <> 1 AND RoleID <> 2)"
        WETCommand.Connection = ConnString
        Try
            WETCommand.ExecuteNonQuery()
        Finally
            ConnString.Close()
        End Try

        ' attempt to create the DNN user
        UserController.UpdateUser(PortalId, User)
    End Sub

    Protected Sub SyncUser(ByVal UserName As String)
        ' perform some tasks
        Dim domain1 As New System.DirectoryServices.DirectoryEntry
        Dim search1 As New System.DirectoryServices.DirectorySearcher

        Dim LDAPString As String = ""

        If System.Configuration.ConfigurationManager.AppSettings("LDAP") Is Nothing = False Then
            LDAPString = System.Configuration.ConfigurationManager.AppSettings("LDAP").ToString & "DC=ad,DC=pwgsc-tpsgc,DC=gc,DC=ca"
            domain1 = New System.DirectoryServices.DirectoryEntry(LDAPString, "pwgsc-tpsgc-em\" & txtUserName.Text, txtPassword.Text, DirectoryServices.AuthenticationTypes.ReadonlyServer)
        Else
            Dim ModController As New DotNetNuke.Entities.Modules.ModuleController
            Dim hash As Hashtable = ModController.GetModuleSettings(ModuleConfiguration.ModuleID)
            If String.IsNullOrEmpty(hash("LDAP")) = False Then
                LDAPString = hash("LDAP")
            End If
            domain1 = New System.DirectoryServices.DirectoryEntry(LDAPString, hash("LDAPDomain") & "\" & txtUserName.Text, txtPassword.Text, DirectoryServices.AuthenticationTypes.ReadonlyServer)
        End If

        search1 = New System.DirectoryServices.DirectorySearcher("(&(objectCategory=Person)(objectclass=User))")
        search1.PageSize = 2000
        search1.SearchRoot = domain1
        Dim Search As Boolean = True
        search1.Filter = "(sAMAccountName=" & UserName & ")"

        search1.SearchScope = System.DirectoryServices.SearchScope.Subtree

        Dim results1 As System.DirectoryServices.SearchResultCollection

        results1 = search1.FindAll

        If Search Then
            For i As Integer = 0 To results1.Count - 1
                Dim Exists As Integer = DoesEmployeeExist(results1(i).Properties("sAMAccountName")(0).ToString())
                ' Check if the user exists or if a new one has to be created
                Dim streetAddress, l, st, postalCode, cell, fax, title, department, company, office, givenname, surname, mail, telephone As String
                If results1(i).Properties.Contains("streetAddress") Then streetAddress = results1(i).Properties("streetAddress")(0).ToString() Else streetAddress = " "
                If results1(i).Properties.Contains("l") Then l = results1(i).Properties("l")(0).ToString() Else l = " "
                If results1(i).Properties.Contains("st") Then st = results1(i).Properties("st")(0).ToString() Else st = " "
                If results1(i).Properties.Contains("postalCode") Then postalCode = results1(i).Properties("postalCode")(0).ToString() Else postalCode = " "
                If results1(i).Properties.Contains("mobile") Then cell = results1(i).Properties("mobile")(0).ToString() Else cell = " "
                If results1(i).Properties.Contains("facsimileTelephoneNumber") Then fax = results1(i).Properties("facsimileTelephoneNumber")(0).ToString() Else fax = " "
                If results1(i).Properties.Contains("title") Then title = results1(i).Properties("title")(0).ToString() Else title = " "
                If results1(i).Properties.Contains("givenname") Then givenname = results1(i).Properties("givenname")(0).ToString() Else givenname = " "
                If results1(i).Properties.Contains("sn") Then surname = results1(i).Properties("sn")(0).ToString() Else surname = " "
                If results1(i).Properties.Contains("mail") Then mail = results1(i).Properties("mail")(0).ToString() Else mail = " "
                If results1(i).Properties.Contains("telephoneNumber") Then telephone = results1(i).Properties("telephoneNumber")(0).ToString() Else telephone = " "

                streetAddress = streetAddress.Replace(Chr(13), " ")
                streetAddress = streetAddress.Replace(Chr(10), " ")

                'If the user is enabled
                Dim AccountAdded As Boolean = False
                If Exists = 0 Then
                    'Create a new user account as the user doesn't exist
                    CreateNewUser(givenname, surname, results1(i).Properties("sAMAccountName")(0).ToString(), mail, telephone, streetAddress, l, st, postalCode, cell, fax, title)
                ElseIf Exists > 1 Then
                    'update the user
                    UpdateUser(Exists, givenname, surname, results1(i).Properties("sAMAccountName")(0).ToString(), mail, telephone, streetAddress, l, st, postalCode, cell, fax, title)
                ElseIf Exists < 0 And TabId <> 1208 Then
                    'The user exists but has been disabled, reactivate the account and update the information
                    ReactivateUser(Math.Abs(Exists), givenname, surname, results1(i).Properties("sAMAccountName")(0).ToString(), mail, telephone, streetAddress, l, st, postalCode)
                End If
            Next

        End If
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        btnLdap.Visible = UserInfo.IsSuperUser
        btnTogglePassword.Visible = UserInfo.IsSuperUser

        If Page.IsPostBack = False Then
            pnlLDAP.ToolTip = Localization.GetString("titleLDAP.Text", Me.LocalResourceFile)
            pnlSendPassword.ToolTip = Localization.GetString("titlePassword.Text", Me.LocalResourceFile)
            pnlTerms.ToolTip = Localization.GetString("titleTerms.Text", Me.LocalResourceFile)

            Dim ModController As New DotNetNuke.Entities.Modules.ModuleController
            Dim hash As Hashtable = ModController.GetModuleSettings(ModuleId)
            If String.IsNullOrEmpty(hash("LDAP")) = False Then
                txtLDAP.Text = hash("LDAP")
                txtDomain.Text = hash("LDAPDomain")
            End If

            hash = New Hashtable
            hash = ModController.GetModuleSettings(ModuleId)
            If String.IsNullOrEmpty(hash("ShowForgotPassword")) = False Then
                btnForgotPassword.Visible = hash("ShowForgotPassword")
            End If
        End If
    End Sub

    Protected Sub btnUpdateLDAP_Click(sender As Object, e As System.EventArgs) Handles btnUpdateLDAP.Click
        Dim modController As New DotNetNuke.Entities.Modules.ModuleController
        modController.UpdateModuleSetting(ModuleId, "LDAP", txtLDAP.Text)
        modController.UpdateModuleSetting(ModuleId, "LDAPDomain", txtDomain.Text)
        AddMessage(Localization.GetString("msgUpdateLdap.Text", Me.LocalResourceFile), "Success")
    End Sub

    Protected Sub btnTogglePassword_Click(sender As Object, e As System.EventArgs) Handles btnTogglePassword.Click
        Dim modController As New DotNetNuke.Entities.Modules.ModuleController
        If btnForgotPassword.Visible Then
            btnForgotPassword.Visible = False
        Else
            btnForgotPassword.Visible = True
        End If
        modController.UpdateModuleSetting(ModuleId, "ShowForgotPassword", btnForgotPassword.Visible)
    End Sub
End Class
