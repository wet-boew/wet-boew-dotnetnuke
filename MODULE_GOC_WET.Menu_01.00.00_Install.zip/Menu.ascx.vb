﻿Imports DotNetNuke.Entities.Tabs

Partial Class DesktopModules_WET_Menu_Menu
    Inherits DotNetNuke.Entities.Modules.PortalModuleBase

    Dim MC As New DotNetNuke.Entities.Modules.ModuleController
    Dim TC As New TabController
    Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name
    Dim LC As New LocaleController
    Dim DefaultLocale As String = LC.GetDefaultLocale(PortalSettings.PortalId).Code

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Try

            If Page.IsPostBack = False Then
                Dim hash As Hashtable = MC.GetModuleSettings(ModuleId)
                ltlMenu.Text = ""
                Dim ParentTab As Integer = -1
                Dim SubPages As String = "False"
                Dim ShowHidden As String = "False"

                If String.IsNullOrEmpty(hash("Recursive")) = False Then
                    SubPages = hash("Recursive").ToString
                End If

                If String.IsNullOrEmpty(hash("IncludeInvisible")) = False Then
                    ShowHidden = hash("IncludeInvisible").ToString
                End If

                If String.IsNullOrEmpty(hash("ParentTab")) Then
                    ParentTab = TabId
                Else
                    ParentTab = Integer.Parse(hash("ParentTab").ToString)
                End If

                LoadMenu(ParentTab, SubPages, ShowHidden)
                ltlMenu.Text = ltlMenu.Text.Replace("<ul></ul></li>", "</li>")

                If ModuleConfiguration.PaneName.ToUpper = "CONTENTPANE" Or ModuleConfiguration.PaneName.ToUpper = "MEDIAPANE" Then
                    ltlMenu.Text = "<ul class='column-two'>" & ltlMenu.Text & "</ul>"
                Else
                    ltlMenu.Text = "<ul>" & ltlMenu.Text & "</ul>"
                End If

                If IsEditable Then
                    PopulateDDL()
                    ddlPages.SelectedValue = ParentTab
                    cbxMenu.Checked = SubPages
                    cbxShowHidden.Checked = ShowHidden
                    pnlAdmin.ToolTip = Localization.GetString("titleAdmin", Me.LocalResourceFile)
                End If
            End If
            btnAdmin.Visible = IsEditable
        Catch ex As Exception
            DotNetNuke.Services.Exceptions.LogException(ex)
            If UserInfo.IsSuperUser Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, ex.Message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("msgError.Text", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If
        End Try
    End Sub

    Protected Sub LoadMenu(ByVal ParentID As Integer, ByVal SubPages As Boolean, ByVal ShowHidden As Boolean)
        'Get list of pages

        For Each T As TabInfo In TabController.GetTabsByParent(ParentID, PortalSettings.PortalId)
            Dim TabName As String
            TabName = T.TabName
            Dim NavCurrent As String = ""
            If T.TabID = PortalSettings.ActiveTab.TabID Then NavCurrent = "class='nav-current' "

            'Grab the other language if one exists
            If DefaultLocale <> ThisLocale Then
                Dim hash As Hashtable = TC.GetTabSettings(T.TabID)
                If String.IsNullOrEmpty(hash("PageTitle" & ThisLocale)) = False Then
                    TabName = hash("PageTitle" & ThisLocale).ToString
                End If
            End If

            If ((T.IsVisible And ShowHidden = False) Or ShowHidden) And T.IsDeleted = False Then
                If PortalSecurity.IsInRoles(T.AuthorizedRoles) Then
                    If T.HasChildren Then
                        If ModuleConfiguration.PaneName.ToUpper = "LEFTPANE" Then
                            If T.DisableLink Then
                                ltlMenu.Text = ltlMenu.Text & "<li class='top-level'><a " & NavCurrent & "href='#'>" & TabName & "</a></li>"
                            Else
                                ltlMenu.Text = ltlMenu.Text & "<li class='top-level'><a " & NavCurrent & "href='" & T.FullUrl & "'>" & TabName & "</a></li>"
                            End If
                            LoadMenu(T.TabID, SubPages, ShowHidden)
                        Else
                            If T.DisableLink Then
                                ltlMenu.Text = ltlMenu.Text & "<li><a " & NavCurrent & "href='#'>" & TabName & "</a>"
                                If SubPages And T.HasChildren Then
                                    ltlMenu.Text = ltlMenu.Text & "<ul>"
                                    LoadMenu(T.TabID, SubPages, ShowHidden)
                                    ltlMenu.Text = ltlMenu.Text & "</ul></li>"
                                Else
                                    ltlMenu.Text = ltlMenu.Text & "</li>"
                                End If
                            Else
                                ltlMenu.Text = ltlMenu.Text & "<li><a " & NavCurrent & "href='" & T.FullUrl & "'>" & TabName & "</a>"
                                If SubPages And T.HasChildren Then
                                    ltlMenu.Text = ltlMenu.Text & "<ul>"
                                    LoadMenu(T.TabID, SubPages, ShowHidden)
                                    ltlMenu.Text = ltlMenu.Text & "</ul></li>"
                                Else
                                    ltlMenu.Text = ltlMenu.Text & "</li>"
                                End If
                            End If
                        End If
                    Else
                        If T.DisableLink Then
                            ltlMenu.Text = ltlMenu.Text & "<li><a " & NavCurrent & "href='#'>" & TabName & "</a></li>"
                        Else
                            ltlMenu.Text = ltlMenu.Text & "<li><a " & NavCurrent & "href='" & T.FullUrl & "'>" & TabName & "</a></li>"
                        End If
                    End If
                End If
            End If
        Next

    End Sub

    Protected Sub PopulateDDL()
        ddlPages.Items.Clear()
        ddlPages.Items.Add(New ListItem(Localization.GetString("RootItem", Me.LocalResourceFile), "-1"))
        'Get list of pages
        For Each T As TabInfo In TabController.GetPortalTabs(PortalId, -1, False, "", True, False, True, True, False)
            Dim AdjustedName As String = T.TabName
            Dim level As Integer = T.Level
            If level <> 0 Then AdjustedName = "» " & AdjustedName
            While level > 1
                AdjustedName = "&nbsp;&nbsp;&nbsp;&nbsp;" & AdjustedName
                level = level - 1
            End While
            ddlPages.Items.Add(New ListItem(HttpUtility.HtmlDecode(AdjustedName), T.TabID))
        Next

    End Sub

    Protected Sub btnSave_Click(sender As Object, e As System.EventArgs) Handles btnSave.Click
        Dim hash As Hashtable = MC.GetModuleSettings(ModuleId)

        MC.UpdateModuleSetting(ModuleId, "Recursive", cbxMenu.Checked)
        MC.UpdateModuleSetting(ModuleId, "ParentTab", ddlPages.SelectedValue)
        MC.UpdateModuleSetting(ModuleId, "IncludeInvisible", cbxShowHidden.Checked)

        Response.Redirect(PortalSettings.ActiveTab.FullUrl)
    End Sub
End Class
