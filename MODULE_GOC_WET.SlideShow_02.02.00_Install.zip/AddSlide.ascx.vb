﻿Imports DotNetNuke
Imports DotNetNuke.Security
Imports DotNetNuke.Entities.Users
Imports System.IO
Imports System.Collections
Imports System.Drawing.Imaging
Imports System.Drawing
Imports System.Data
Imports System.Data.SqlClient

Partial Class DesktopModules_SlideShow_AddSlide
    Inherits DotNetNuke.Entities.Modules.PortalModuleBase
    Dim LangController As New LocaleController

    'TODO: Refactor this page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            If LangController.GetCurrentLocale(PortalSettings.PortalId).Code.ToLower.Contains("fr") Then
                language.SelectedValue = "french"
            Else
                language.SelectedValue = "english"
            End If
            LoadSlides()
        End If
    End Sub
    Protected Sub LoadSlides()
        Try
            Using sqlConnection As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
                Dim sqlCommand As New SqlCommand
                sqlCommand.CommandType = CommandType.Text
                sqlCommand.CommandText = "SELECT * from SlideShow WHERE ModuleID = @ModuleID ORDER BY SlideNumber"
                sqlCommand.Parameters.AddWithValue("@ModuleID", ModuleId)
                sqlCommand.Connection = sqlConnection

                sqlCommand.Connection.Open()

                editGrid.DataSource = sqlCommand.ExecuteReader()
                editGrid.DataBind()

                If editGrid.Rows.Count = 0 Then
                    noSlides.Text = "<b>You have not added any slides to this slide show yet.</b>"
                    updateSlides.Visible = False
                Else
                    noSlides.Visible = False
                    updateSlides.Visible = True
                End If

                sqlCommand.Connection.Close()
                sqlCommand.Connection.Dispose()
            End Using

            For Each row As GridViewRow In editGrid.Rows
                Dim DGPhoto As System.Web.UI.WebControls.Image = DirectCast(row.FindControl("DGPhoto"), System.Web.UI.WebControls.Image)
                Dim DGTitle As TextBox = DirectCast(row.FindControl("DGTitle"), TextBox)
                Dim DGLink As TextBox = DirectCast(row.FindControl("DGLink"), TextBox)
                Dim DGDescription As TextBox = DirectCast(row.FindControl("DGDescription"), TextBox)

                Dim DGPhotoFr As System.Web.UI.WebControls.Image = DirectCast(row.FindControl("DGPhotoFr"), System.Web.UI.WebControls.Image)
                Dim DGTitleFr As TextBox = DirectCast(row.FindControl("DGTitleFr"), TextBox)
                Dim DGLinkFr As TextBox = DirectCast(row.FindControl("DGLinkFr"), TextBox)
                Dim DGDescriptionFr As TextBox = DirectCast(row.FindControl("DGDescriptionFr"), TextBox)

                If language.SelectedValue = "french" Then
                    DGPhotoFr.Visible = True
                    DGTitleFr.Visible = True
                    DGLinkFr.Visible = True
                    DGDescriptionFr.Visible = True
                    DGPhoto.Visible = False
                    DGTitle.Visible = False
                    DGLink.Visible = False
                    DGDescription.Visible = False
                Else
                    DGPhotoFr.Visible = False
                    DGTitleFr.Visible = False
                    DGLinkFr.Visible = False
                    DGDescriptionFr.Visible = False
                    DGPhoto.Visible = True
                    DGTitle.Visible = True
                    DGLink.Visible = True
                    DGDescription.Visible = True
                End If
            Next

        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
    End Sub
    Protected Sub addSlide_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles addSlide.Click
        If photo.HasFile Then
            If (Not System.IO.Directory.Exists(Server.MapPath(".") & "\DesktopModules\WET\SlideShow\Photos\" & ModuleId)) Then
                System.IO.Directory.CreateDirectory(Server.MapPath(".") & "\DesktopModules\WET\SlideShow\Photos\" & ModuleId)
            End If

            Dim FileName As String = Path.GetFileName(photo.PostedFile.FileName)

            Dim FileName2 As String = ""

            'Save files to disk
            photo.SaveAs(Server.MapPath(".") & "\DesktopModules\WET\SlideShow\Photos\" & ModuleId & "\" & FileName)
            'Resize file
            Dim FI As New FileInfo(Server.MapPath(".") & "\DesktopModules\WET\SlideShow\Photos\" & ModuleId & "\" & FileName)
            Dim strFileSize As String = ""
            strFileSize = (Math.Round(FI.Length / 1024)).ToString()
            ResizeImage(FI, 250, strFileSize)

            If photoFr.HasFile Then
                FileName2 = Path.GetFileName(photoFr.PostedFile.FileName)
                'Save files to disk
                photoFr.SaveAs(Server.MapPath(".") & "\DesktopModules\WET\SlideShow\Photos\" & ModuleId & "\" & FileName2)
                'Resize file
                Dim FI2 As New FileInfo(Server.MapPath(".") & "\DesktopModules\WET\SlideShow\Photos\" & ModuleId & "\" & FileName2)
                Dim strFileSize2 As String = ""
                strFileSize2 = (Math.Round(FI2.Length / 1024)).ToString()
                ResizeImage(FI2, 250, strFileSize2)
            End If

            'Add Entry to DataBase
            Using sqlConnection As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
                Dim sqlCommand As New SqlCommand
                sqlCommand.CommandType = CommandType.Text

                sqlCommand.CommandText = "INSERT INTO SlideShow (moduleID, slideNumber, visible, title, description, link, photo, titleFr, descriptionFr, linkFr, photoFr)" & " VALUES(@moduleID, ISNULL((SELECT TOP 1 SlideNumber FROM SlideShow WHERE ModuleID = @ModuleID ORDER BY SlideNumber DESC),0) + 1, @visible, @title, @description, @link, @photo, @titleFr, @descriptionFr, @linkFr, @photoFr)"

                sqlCommand.Connection = sqlConnection

                sqlCommand.Parameters.Add("@moduleID", SqlDbType.Int).Direction = ParameterDirection.Input
                sqlCommand.Parameters.Add("@visible", SqlDbType.Bit).Direction = ParameterDirection.Input
                sqlCommand.Parameters.Add("@title", SqlDbType.VarChar, 500).Direction = ParameterDirection.Input
                sqlCommand.Parameters.Add("@description", SqlDbType.VarChar, 500).Direction = ParameterDirection.Input
                sqlCommand.Parameters.Add("@link", SqlDbType.VarChar, 200).Direction = ParameterDirection.Input
                sqlCommand.Parameters.Add("@photo", SqlDbType.VarChar, 200).Direction = ParameterDirection.Input
                sqlCommand.Parameters.Add("@titleFr", SqlDbType.VarChar, 500).Direction = ParameterDirection.Input
                sqlCommand.Parameters.Add("@descriptionFr", SqlDbType.VarChar, 500).Direction = ParameterDirection.Input
                sqlCommand.Parameters.Add("@linkFr", SqlDbType.VarChar, 200).Direction = ParameterDirection.Input
                sqlCommand.Parameters.Add("@photoFr", SqlDbType.VarChar, 200).Direction = ParameterDirection.Input

                sqlCommand.Parameters("@moduleID").Value = ModuleId
                sqlCommand.Parameters("@visible").Value = True
                If CheckBox1.Checked Then
                    sqlCommand.Parameters("@photo").Value = "~\DesktopModules\WET\SlideShow\Photos\" & ModuleId & "\" & FileName
                    sqlCommand.Parameters("@photoFr").Value = "~\DesktopModules\WET\SlideShow\Photos\" & ModuleId & "\" & FileName
                Else
                    sqlCommand.Parameters("@photo").Value = "~\DesktopModules\WET\SlideShow\Photos\" & ModuleId & "\" & FileName
                    sqlCommand.Parameters("@photoFr").Value = "~\DesktopModules\WET\SlideShow\Photos\" & ModuleId & "\" & FileName2
                End If
                sqlCommand.Parameters("@title").Value = title.Text
                sqlCommand.Parameters("@description").Value = description.Text
                sqlCommand.Parameters("@link").Value = link.Text
                sqlCommand.Parameters("@titleFr").Value = title.Text
                sqlCommand.Parameters("@descriptionFr").Value = description.Text
                sqlCommand.Parameters("@linkFr").Value = link.Text

                Try
                    sqlCommand.Connection.Open()
                    sqlCommand.ExecuteNonQuery()
                Catch ex As Exception
                    Response.Write(ex.Message)
                Finally
                    sqlCommand.Connection.Close()
                    sqlCommand.Dispose()
                End Try
                LoadSlides()
            End Using
        Else
        End If
    End Sub
    Private Sub ResizeImage(ByVal singleFile As FileInfo, ByVal NewSize As Integer, ByVal FileSize As String)
        Dim TestString As String = ""
        Try
            Dim imageUrl As String = singleFile.FullName
            Dim MyFormat As ImageFormat = ImageFormat.Jpeg
            Dim bm As New Bitmap(imageUrl)
            Dim width As Integer = bm.Width
            Dim height As Integer = bm.Height
            'Resize based on height of 250 pixels
            If bm.Height > NewSize Then
                height = NewSize
                width = (NewSize / bm.Height) * bm.Width
            End If
            Dim thumb As New Bitmap(width, height)
            Dim g As Graphics = Graphics.FromImage(thumb)
            g.InterpolationMode = Drawing2D.InterpolationMode.HighQualityBicubic
            g.DrawImage(bm, New Rectangle(0, 0, width, height), New Rectangle(0, 0, bm.Width, bm.Height), GraphicsUnit.Pixel)
            g.Dispose()
            If bm.Height > NewSize Then
                bm.Dispose()
                thumb.Save(imageUrl, MyFormat) 'can use any image format 
            Else
                bm.Dispose()
            End If
            thumb.Dispose()
        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
    End Sub
    Protected Sub editGrid_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles editGrid.RowCommand
        Try
            Using sqlConnection As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
                Dim sqlCommand As New SqlCommand
                sqlCommand.CommandType = CommandType.Text
                sqlCommand.CommandText = "DELETE FROM SlideShow WHERE ID = @ID"
                sqlCommand.Connection = sqlConnection
                sqlCommand.Connection.Open()
                sqlCommand.Parameters.Add("@ID", SqlDbType.Int).Direction = ParameterDirection.Input
                sqlCommand.Parameters("@ID").Value = e.CommandArgument
                sqlCommand.ExecuteNonQuery()
                sqlCommand.Parameters.Clear()
                sqlCommand.Connection.Close()
                sqlCommand.Dispose()
            End Using
        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
        Try
            Dim commandArgs As String() = e.CommandName.ToString().Split(New Char() {","c})
            Dim string1 = commandArgs(0)
            Dim string2 = commandArgs(1)
            If File.Exists(Server.MapPath(string1)) Then
                File.Delete(Server.MapPath(string1))
            End If
            If File.Exists(Server.MapPath(string2)) Then
                File.Delete(Server.MapPath(string2))
            End If
        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
        LoadSlides()
    End Sub

    Protected Sub saveSlideInfo(ByVal sender As Object, ByVal e As EventArgs)
        Using sqlConnection As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
            Dim sqlCommand As New SqlCommand
            sqlCommand.CommandType = CommandType.Text
            If language.SelectedValue = "english" Then
                sqlCommand.CommandText = "UPDATE SlideShow SET title = @title, description = @description, link = @link, visible = @visible, slidenumber = @slidenumber WHERE ID = @ID"
            Else
                sqlCommand.CommandText = "UPDATE SlideShow SET titleFr = @title, descriptionFr = @description, linkFr = @link, visible = @visible, slidenumber = @slidenumber WHERE ID = @ID"
            End If
            sqlCommand.Connection = sqlConnection
            Try
                sqlCommand.Connection.Open()
                For Each row As GridViewRow In editGrid.Rows
                    sqlCommand.Parameters.AddWithValue("@ID", CType(row.FindControl("slideID"), Label).Text)
                    sqlCommand.Parameters.AddWithValue("@visible", CType(row.FindControl("visible"), CheckBox).Checked)
                    sqlCommand.Parameters.AddWithValue("@slidenumber", CType(row.FindControl("DGslideNumber"), TextBox).Text)

                    If language.SelectedValue = "english" Then
                        sqlCommand.Parameters.AddWithValue("@title", CType(row.FindControl("DGtitle"), TextBox).Text)
                        sqlCommand.Parameters.AddWithValue("@description", CType(row.FindControl("DGdescription"), TextBox).Text)
                        sqlCommand.Parameters.AddWithValue("@link", CType(row.FindControl("DGlink"), TextBox).Text)
                    Else
                        sqlCommand.Parameters.AddWithValue("@title", CType(row.FindControl("DGtitleFr"), TextBox).Text)
                        sqlCommand.Parameters.AddWithValue("@description", CType(row.FindControl("DGdescriptionFr"), TextBox).Text)
                        sqlCommand.Parameters.AddWithValue("@link", CType(row.FindControl("DGlinkFr"), TextBox).Text)
                    End If

                    sqlCommand.ExecuteNonQuery()
                    sqlCommand.Parameters.Clear()

                    Page.ClientScript.RegisterStartupScript(Me.GetType(), "alert", "Saved();", True)

                Next
            Catch ex As Exception
                Response.Write(ex.Message)
            Finally
                sqlCommand.Connection.Close()
                sqlCommand.Dispose()
            End Try
            LoadSlides()
        End Using
    End Sub

    Protected Sub language_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles language.SelectedIndexChanged
        LoadSlides()
    End Sub


    Protected Sub CheckBox1_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            photoLabelFr.Visible = True
            photoFr.Visible = True
        Else
            photoLabelFr.Visible = False
            photoFr.Visible = False
        End If
    End Sub
End Class
