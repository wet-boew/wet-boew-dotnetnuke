﻿Imports DotNetNuke
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Security
Imports DotNetNuke.Entities.Users
Imports System.Data.Sql
Imports System.Data.SqlClient
Partial Class DesktopModules_WET_SlideShow_SlideShow
    Inherits DotNetNuke.Entities.Modules.PortalModuleBase
    Implements Entities.Modules.IActionable

    Dim LangController As New LocaleController
    Dim HasLeftPane As Boolean = False
    Dim HasRightPane As Boolean = False
    Dim Style As String = ""

    Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
        Get
            Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
            Actions.Add(GetNextActionID, Localization.GetString("AddSlide", LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", _
            EditUrl("AddSlide"), False, SecurityAccessLevel.Edit, True, False)
            Return Actions
        End Get
    End Property

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Dim MC As New ModuleController

        Try
            'Get Size
            Dim SpanLeft As String = "3"
            Dim SpanRight As String = "9"

            If ModuleConfiguration.PaneName = "LeftPane" Or ModuleConfiguration.PaneName = "RightPane" Then
                SpanLeft = "1"
                SpanRight = "2"
            ElseIf ModuleConfiguration.PaneName = "ContentPane" Then
                Dim HasLeftPane As Boolean = False
                Dim HasRightPane As Boolean = False

                For Each PageMod As ModuleInfo In MC.GetTabModules(PortalSettings.ActiveTab.TabID).Values
                    If PageMod.IsDeleted = False Then
                        If PageMod.PaneName = "LeftPane" Then
                            HasLeftPane = True
                        ElseIf PageMod.PaneName = "RightPane" Then
                            HasRightPane = True
                        End If
                    End If
                Next

                If HasLeftPane And HasRightPane Then
                    SpanLeft = "2"
                    SpanRight = "4"
                ElseIf HasLeftPane Or HasRightPane Then
                    SpanLeft = "3"
                    SpanRight = "6"
                End If
            End If

            SpanLeft = "row-start span-" & SpanLeft
            SpanRight = "row-end span-" & SpanRight

            If ModuleConfiguration.PaneName <> "MediaPane" And ModuleConfiguration.PaneName <> "ContentPane" And ModuleConfiguration.PaneName <> "LeftPane" And ModuleConfiguration.PaneName <> "RightPane" Then
                SpanLeft = "margin-right-none width-40"
                SpanRight = "indent-none width-60"
            End If

            'Get which side the picture will be on
            Dim objModules As New DotNetNuke.Entities.Modules.ModuleController
            objModules.GetModuleSettings(ModuleId)
            Dim hash As Hashtable = objModules.GetModuleSettings(ModuleId)

            Dim Inverted As Boolean = False
            'Save which side the picture displays on
            If String.IsNullOrEmpty(hash("Inverted")) = False Then
                If hash("Inverted") = "True" Then
                    Inverted = True
                End If
            End If

            'Get Images
            Using Connection As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
                Dim tabsPanelStr As String = ""
                Dim tabsStr As String = ""
                Dim command As New SqlCommand
                command.CommandText = "SELECT * FROM SlideShow WHERE ModuleID = @ModuleID Order By SlideNumber"
                command.Parameters.AddWithValue("@ModuleID", ModuleId)
                command.Connection = Connection
                Try
                    command.Connection.Open()
                    Dim reader As SqlDataReader = command.ExecuteReader
                    Dim SlideNum As Integer = 1
                    While reader.Read
                        If reader.Item("visible") = "True" Then

                            Dim fr As String = ""
                            If LangController.GetCurrentLocale(PortalSettings.PortalId).Code.ToLower.Contains("fr") Then
                                fr = "Fr"
                            End If

                            'Check if no description and title
                            Dim NoText As Boolean = False
                            If reader.Item("description" & fr).ToString = "" And reader.Item("title" & fr).ToString = "" Then
                                NoText = True
                            End If

                            If NoText Then
                                tabsPanelStr = tabsPanelStr & "<div id='tab" & SlideNum & "' style='background-color:white;' class='panel' ><section>" & _
                                   "<div class='float-left slide-image width-100' ><a href='" & reader.Item("link" & fr) & "'><img style='height:250px;' class='float-left' src='" & reader.Item("photo" & fr).Replace("\", "/").Replace("~", "") & "' alt='" & reader.Item("description" & fr) & "' /></a></div>" & _
                                   "<div class='clear'></div></section></div>"
                            ElseIf Inverted Then
                                tabsPanelStr = tabsPanelStr & "<div id='tab" & SlideNum & "' class='panel' ><section>" & _
                                   "<div class='float-right slide-text " & SpanLeft.Replace("start", "end") & "' ><div class='tabs-content-pad'><p class='font-xlarge margin-top-none'>" & reader.Item("title" & fr) & "</p><p>" & reader.Item("description" & fr) & "</p><p><a href='" & reader.Item("link" & fr) & "' class='button button-accent'>" & Localization.GetString("Continue", LocalResourceFile) & "</a></p></div></div>" & _
                                   "<div class='float-left slide-image " & SpanRight.Replace("end", "start") & "' ><img style='height:250px;' class='float-left' src='" & reader.Item("photo" & fr).Replace("\", "/").Replace("~", "") & "' alt='" & reader.Item("description" & fr) & "' /></div>" & _
                                   "<div class='clear'></div></section></div>"
                            Else
                                tabsPanelStr = tabsPanelStr & "<div id='tab" & SlideNum & "' class='panel' ><section>" & _
                                   "<div class='float-left slide-text " & SpanLeft & "' ><div class='tabs-content-pad'><p class='font-xlarge margin-top-none'>" & reader.Item("title" & fr) & "</p><p>" & reader.Item("description" & fr) & "</p><p><a href='" & reader.Item("link" & fr) & "'  class='button button-accent'>" & Localization.GetString("Continue", LocalResourceFile) & "</a></p></div></div>" & _
                                   "<div class='float-right slide-image " & SpanRight & "' ><img style='height:250px;' class='float-right' src='" & reader.Item("photo" & fr).Replace("\", "/").Replace("~", "") & "' alt='" & reader.Item("description" & fr) & "' /></div>" & _
                                   "<div class='clear'></div></section></div>"
                            End If

                                tabsStr = tabsStr & "<li><a href='#tab" & SlideNum & "'>" & SlideNum & "</a></li>"

                                SlideNum = SlideNum + 1
                            End If
                    End While

                    tabsMenu.Text = tabsStr
                    tabsPanel.Text = tabsPanelStr

                Finally
                    command.Connection.Close()
                End Try
            End Using
        Catch ex As Exception
            If UserInfo.IsSuperUser Then Response.Write(ex.Message)
        End Try
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        btnPictureSide.Visible = IsEditable
    End Sub

    Protected Sub btnPictureSide_Click(sender As Object, e As System.EventArgs) Handles btnPictureSide.Click

        Dim objModules As New DotNetNuke.Entities.Modules.ModuleController
        objModules.GetModuleSettings(ModuleId)
        Dim hash As Hashtable = objModules.GetModuleSettings(ModuleId)

        'Save which side the picture displays on
        If String.IsNullOrEmpty(hash("Inverted")) Then
            objModules.UpdateModuleSetting(ModuleId, "Inverted", "True")
        Else
            If hash("Inverted") = "False" Then
                objModules.UpdateModuleSetting(ModuleId, "Inverted", "True")
            Else
                objModules.UpdateModuleSetting(ModuleId, "Inverted", "False")
            End If
        End If

        Response.Redirect(PortalSettings.ActiveTab.FullUrl.Replace(System.Globalization.CultureInfo.CurrentUICulture.Name.ToLower + "/", ""))

    End Sub
End Class






