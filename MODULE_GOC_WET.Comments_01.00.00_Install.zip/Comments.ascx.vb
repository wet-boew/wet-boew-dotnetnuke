﻿
Partial Class DesktopModules_PWGSC_Comments_Comments
    Inherits DotNetNuke.Entities.Modules.PortalModuleBase

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        pnlTerms.ToolTip = Localization.GetString("lblTerms.Text", Me.LocalResourceFile)
        If Page.IsPostBack = False Then
            LoadComments()
        End If
    End Sub


    Protected Sub AddMessage(ByVal Message As String, ByVal Type As String)
        If Type = "Error" Then
            If UserInfo.IsSuperUser Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("msgError.Text", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If
        ElseIf Type = "Success" Then
            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Message, Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
        ElseIf Type = "Warning" Then
            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Message, Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
        ElseIf Type = "Information" Then
            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Message, Skins.Controls.ModuleMessage.ModuleMessageType.BlueInfo)
        End If
    End Sub


    Protected Sub LoadComments()
        Dim ConnString As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
        ConnString.Open()

        Dim PWGSCDataset As New DataSet
        Dim PWGSCCommand As New SqlCommand
        PWGSCCommand.CommandText = "SELECT ID, ModuleID, REPLACE(Comment,CHAR(13),'<br />') AS Comment, CommentBy, CAST(DateSubmitted AS VARCHAR(50)) AS 'DateSubmitted' FROM Comments WHERE ModuleID = @ModuleID"
        PWGSCCommand.Parameters.AddWithValue("@ModuleID", ModuleId)
        PWGSCCommand.Connection = ConnString
        Try
            lstComments.DataSource = PWGSCCommand.ExecuteReader
            lstComments.DataBind()
        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        Finally
            ConnString.Close()
        End Try
    End Sub

    Protected Sub btnAdd_Click(sender As Object, e As System.EventArgs) Handles btnAdd.Click
        If String.IsNullOrEmpty(txtComment.Text) = False And String.IsNullOrEmpty(txtCommentBy.Text) = False Then
            Dim ConnString As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
            ConnString.Open()

            Dim PWGSCDataset As New DataSet
            Dim PWGSCCommand As New SqlCommand
            PWGSCCommand.CommandText = "INSERT INTO Comments(ModuleID, Comment, CommentBy, DateSubmitted) VALUES(@ModuleID, @Comment, @CommentBy, GETDATE())"
            PWGSCCommand.Parameters.AddWithValue("@ModuleID", ModuleId)
            PWGSCCommand.Parameters.AddWithValue("@Comment", txtComment.Text)
            PWGSCCommand.Parameters.AddWithValue("@CommentBy", txtCommentBy.Text)
            PWGSCCommand.Connection = ConnString
            Try
                PWGSCCommand.ExecuteNonQuery()
            Catch ex As Exception
                AddMessage(ex.Message, "Error")
                DotNetNuke.Services.Exceptions.LogException(ex)
            Finally
                ConnString.Close()
            End Try
            LoadComments()
        End If
    End Sub

    Protected Sub lstComments_ItemDeleting(sender As Object, e As System.Web.UI.WebControls.ListViewDeleteEventArgs) Handles lstComments.ItemDeleting
        Dim ConnString As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
        ConnString.Open()

        Dim PWGSCDataset As New DataSet
        Dim PWGSCCommand As New SqlCommand
        PWGSCCommand.CommandText = "DELETE FROM Comments WHERE ID = @ID"
        Try
            PWGSCCommand.Parameters.AddWithValue("@ID", CType(lstComments.Items(e.ItemIndex).FindControl("lblID"), Label).Text)
            PWGSCCommand.Connection = ConnString
            PWGSCCommand.ExecuteNonQuery()
        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        Finally
            ConnString.Close()
        End Try
        LoadComments()
    End Sub
End Class
