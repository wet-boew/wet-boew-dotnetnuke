﻿Imports DotNetNuke.Entities.Tabs

Partial Class Portals__default_Skins_CLF3___DNN6_Skin_Objects_Menu
    Inherits DotNetNuke.UI.Skins.SkinObjectBase


    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Try
            GetPages() ' Main menu
            lblMenu.Text = "<div><ul class='mb-menu'>" & lblMenu.Text & "</ul></div>"
            'Response.Write(HttpUtility.HtmlEncode(lblMenu.Text))
        Catch ex As Exception
            If PortalSettings.UserInfo.IsSuperUser Then lblMenu.Text = ex.Message
        End Try
    End Sub

    Protected Sub GetPages()
        Try
            Dim LastLevel As Integer = -1
            Dim RootTab As New TabInfo
            Dim MainPage As String = Localization.GetString("SKINMenuMain.Text", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
            Dim HiddenTabs As String = "@"
            Dim PageURL As String = "#"

            'Check other language
            Dim TC As New TabController
            Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name
            Dim LC As New LocaleController
            Dim DefaultLocale As String = LC.GetDefaultLocale(PortalSettings.PortalId).Code
            Dim MainTitle As String = ""
            Dim RootTitle As String = ""

            'Get list of visible pages
            For Each T As TabInfo In TabController.GetPortalTabs(PortalSettings.PortalId, -1, False, "", True, False, True, True, True)
                'Check for disabled page links
                PageURL = "#"
                If T.DisableLink = False Then PageURL = T.FullUrl.ToLower.Replace("en-ca/", "").Replace("en-us/", "").Replace("fr-ca/", "")

                If LastLevel = -1 Then
                    RootTab = T
                    RootTitle = T.TabName
                End If
                If T.IsVisible = False Or HiddenTabs.Contains("@" & T.ParentId & "@") Then HiddenTabs = HiddenTabs & T.TabID & "@"

                'Check if the tab has a hidden parent
                If HiddenTabs.Contains("@" & T.TabID & "@") = False And T.Level <= 2 Then
                    'Set Other Locale

                    MainTitle = T.TabName
                    If DefaultLocale <> ThisLocale Then
                        Dim hash As Hashtable = TC.GetTabSettings(T.TabID)
                        If String.IsNullOrEmpty(hash("PageTitle" & ThisLocale)) = False Then
                            MainTitle = hash("PageTitle" & ThisLocale).ToString
                            If T.TabID = RootTab.TabID Then RootTitle = MainTitle
                        End If
                    End If

                    'Third level close tag
                    If T.Level <= 1 And LastLevel = 2 Then
                        lblMenu.Text = lblMenu.Text & "</ul>"
                    End If

                    'Second Level mid close tag
                    If T.Level <= 1 And LastLevel >= 1 Then
                        lblMenu.Text = lblMenu.Text & "</section></div>"
                    End If

                    'Second level root close tag
                    If T.Level = 0 And LastLevel >= 1 Then
                        If RootTab.DisableLink Then
                            lblMenu.Text = lblMenu.Text & "<div class='clear'></div></div>"
                        Else
                            lblMenu.Text = lblMenu.Text & "<div class='clear'></div><div class='mb-main-link'>" & _
                           "<a href='" & RootTab.FullUrl.ToLower.Replace("en-ca/", "").Replace("en-us/", "").Replace("fr-ca/", "") & "'>" & RootTitle & " - " & MainPage & "</a></div></div>"
                        End If

                        'Last had no subchildren
                        If LastLevel = 1 Then
                            'Remove top level for a basic link
                            lblMenu.Text = lblMenu.Text.Replace("[SECTION1OPEN]", "<ul><li class='top-level'>")
                            lblMenu.Text = lblMenu.Text.Replace("[SECTION1CLOSE]", "</li></ul>")
                        Else
                            lblMenu.Text = lblMenu.Text.Replace("[SECTION1OPEN]", "<section><h4>")
                            lblMenu.Text = lblMenu.Text.Replace("[SECTION1CLOSE]", "</h4>")
                        End If
                    End If

                    If T.Level = 0 Then
                        RootTab = New TabInfo()
                        RootTab = T
                        RootTitle = MainTitle
                    End If

                    'First level close tag
                    If T.Level = 0 And LastLevel >= 0 Then
                        lblMenu.Text = lblMenu.Text & "</section></li>"

                        'Had no subchildren
                        If T.Level = 0 And LastLevel = 0 Then
                            lblMenu.Text = lblMenu.Text.Replace("[SECTION0OPEN]", "<div>")
                            lblMenu.Text = lblMenu.Text.Replace("[SECTION0CLOSE]", "</div>")
                        Else
                            lblMenu.Text = lblMenu.Text.Replace("[SECTION0OPEN]", "<section><h3>")
                            lblMenu.Text = lblMenu.Text.Replace("[SECTION0CLOSE]", "</h3>")
                        End If

                    End If

                    'Second level prefix tag
                    If T.Level = 1 And LastLevel = 0 Then
                        lblMenu.Text = lblMenu.Text & "<div class='mb-sm'>"
                    End If

                    'Third level prefix tag
                    If T.Level = 2 And LastLevel = 1 Then
                        lblMenu.Text = lblMenu.Text & "<ul>"
                    End If


                    If T.Level = 0 Then

                        lblMenu.Text = lblMenu.Text & "<li>[SECTION0OPEN]<a href='" & PageURL & "'>" & MainTitle & "</a>[SECTION0CLOSE]"

                    ElseIf T.Level = 1 Then

                        lblMenu.Text = lblMenu.Text & "<div class='span-2'>[SECTION1OPEN]<a href='" & PageURL & "'>" & MainTitle & "</a>[SECTION1CLOSE]"

                    ElseIf T.Level = 2 Then

                        lblMenu.Text = lblMenu.Text & "<li><a href='" & PageURL & "'>" & MainTitle & "</a></li>"

                    End If

                    LastLevel = T.Level
                End If

            Next

            'Third level close tag
            If LastLevel = 2 Then
                lblMenu.Text = lblMenu.Text & "</ul>"
            End If

            'Second level root close tag
            If LastLevel >= 1 Then
                If RootTab.DisableLink Then
                    lblMenu.Text = lblMenu.Text & "</div><div class='clear'></div></div>"
                Else
                    lblMenu.Text = lblMenu.Text & "</div><div class='clear'></div><div class='mb-main-link'>" & _
                   "<a href='" & RootTab.FullUrl.ToLower.Replace("en-ca/", "").Replace("en-us/", "").Replace("fr-ca/", "") & "'>" & RootTitle & " - " & MainPage & "</a></div></div>"
                End If

                'Last had no subchildren
                If LastLevel = 1 Then
                    'Remove top level for a basic link
                    lblMenu.Text = lblMenu.Text.Replace("[SECTION1OPEN]", "<ul><li class='top-level'>")
                    lblMenu.Text = lblMenu.Text.Replace("[SECTION1CLOSE]", "</li></ul>")
                Else
                    lblMenu.Text = lblMenu.Text.Replace("[SECTION1OPEN]", "<section><h4>")
                    lblMenu.Text = lblMenu.Text.Replace("[SECTION1CLOSE]", "</h4>")
                End If
            End If

            'First level close tag
            If LastLevel >= 0 Then
                lblMenu.Text = lblMenu.Text & "</section></li>"

                'Had no subchildren
                If LastLevel = 0 Then
                    lblMenu.Text = lblMenu.Text.Replace("[SECTION0OPEN]", "<div>")
                    lblMenu.Text = lblMenu.Text.Replace("[SECTION0CLOSE]", "</div>")
                Else
                    lblMenu.Text = lblMenu.Text.Replace("[SECTION0OPEN]", "<section><h3>")
                    lblMenu.Text = lblMenu.Text.Replace("[SECTION0CLOSE]", "</h3>")
                End If
            End If

        Catch ex As Exception
            If PortalSettings.UserInfo.IsSuperUser Then lblMenu.Text = ex.Message
        End Try
    End Sub


End Class
