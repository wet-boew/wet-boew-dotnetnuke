﻿Imports System.Collections.Generic
Partial Class Portals__default_Skins_CLF3___DNN6_Skin_Objects_Langage
    Inherits DotNetNuke.UI.Skins.SkinObjectBase

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        Try

            Dim LangController As New LocaleController
            Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name
            Dim LinkEnd As String = "fr-CA"
            Dim CurrentURL As String = PortalSettings.ActiveTab.TabPath.Replace("//", "/") & ".aspx"

            If LinkEnd = ThisLocale Then

                'Link to English site, do a check to see if English-CA exists in the site or just US
                LinkEnd = "en-US"
                For Each Loc As Generic.KeyValuePair(Of String, Locale) In LocaleController.Instance.GetLocales(PortalSettings.PortalId)
                    If Loc.Key = "en-CA" Then
                        LinkEnd = Loc.Key
                    End If
                Next

            End If

            'Add the link parameters
            CurrentURL = CurrentURL & "?Language=" & LinkEnd

            For Each key As String In Request.QueryString.AllKeys
                If key.ToLower.Contains("lang") = False And key.ToLower.Contains("tabid") = False Then
                    CurrentURL = CurrentURL & "&" & key & "=" & Request.QueryString(key)
                End If
            Next

            'Get the resource and add the link to it
            lblLanguage.Text = Localization.GetString("SKINLanguageOverride", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
            lblLanguage.Text = lblLanguage.Text.Replace("[LINK]", CurrentURL)

        Catch ex As Exception
            If PortalSettings.UserInfo.IsSuperUser Then Response.Write("Language Selection Error: " & ex.Message)
        End Try

    End Sub

End Class
