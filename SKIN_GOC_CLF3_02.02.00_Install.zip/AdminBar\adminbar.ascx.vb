﻿Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Security.Permissions
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Definitions
Imports DotNetNuke

Partial Class admin_ControlPanel_adminbar
    Inherits DotNetNuke.UI.ControlPanels.ControlPanelBase
    Dim PC As PortalController
    Dim RC As New DotNetNuke.Security.Roles.RoleController
    Dim TC As New DotNetNuke.Entities.Tabs.TabController

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        pnlErrors.Visible = False
        tblIconBar.Visible = IsPageAdmin()
        SetAdministration()
        If Page.IsPostBack = False Then
            LoadLanguages()
            LoadDDLs()
            LoadPermissionGrid()
            LoadSettings()
            'Set portal mode
            If PortalSettings.UserMode = Entities.Portals.PortalSettings.Mode.View Then
                ddlMode.SelectedIndex = 0
            Else
                ddlMode.SelectedIndex = 1
            End If
        End If
    End Sub

    Protected Sub LoadSettings()
        Try
            'Add Page
            dateAddStart.SelectedDate = Today
            dateAddEnd.SelectedDate = Today.AddYears(1)
            cbxAddIncludeInMenu.Checked = True
            cbxAddVisibleToUsers.Checked = True

            'Page Options
            Dim LangController As New LocaleController
            Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name

            'Multilingual
            If LangController.GetDefaultLocale(PortalSettings.PortalId).Code = ThisLocale Then
                'Use the default site settings
                txtEditPageName.Text = PortalSettings.ActiveTab.TabName
            Else
                'Use the module settings to store the values
                Dim hash As Hashtable = TC.GetTabSettings(PortalSettings.ActiveTab.TabID)
                If String.IsNullOrEmpty(hash("PageTitle" & ThisLocale)) Then
                    txtEditPageName.Text = PortalSettings.ActiveTab.TabName
                Else
                    txtEditPageName.Text = hash("PageTitle" & ThisLocale).ToString
                    Dim changeTitle As DotNetNuke.Framework.CDefault = Me.Page
                    changeTitle.Title = txtEditPageName.Text
                End If
            End If

            cbxEditIncludeInMenu.Checked = PortalSettings.ActiveTab.IsVisible
            For Each TPC In TabPermissionController.GetTabPermissions(PortalSettings.ActiveTab.TabID, PortalSettings.PortalId)
                If TPC.RoleName = "All Users" Then cbxEditVisibleToUsers.Checked = True
            Next

            'Fix for broken dates
            Try
                dateEditEnd.SelectedDate = PortalSettings.ActiveTab.EndDate
                dateEditStart.SelectedDate = PortalSettings.ActiveTab.StartDate
            Catch ex As Exception
                dateEditEnd.SelectedDate = Today.AddYears(1)
                dateEditStart.SelectedDate = Today
            End Try

            'Load Modules
            cbxModVisible.Checked = True
        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        End Try
    End Sub

    Protected Sub SetAdministration()
        'Visibility of admin buttons
        If PortalSettings.UserInfo.IsSuperUser Then
            tblAdministration.Visible = False
            tblHost.Visible = True
        Else
            tblAdministration.Visible = True
            tblHost.Visible = True
        End If
        GetHostViewTabs()
    End Sub

    Protected Sub AddMessage(ByVal Message As String, ByVal Type As String)
        If PortalSettings.UserInfo.IsSuperUser Then
            ltlError.Text = Message
        Else
            ltlError.Text = Localization.GetString("ltlError.Text", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        End If
        pnlErrors.Visible = True
    End Sub

    Protected Sub LoadPermissionGrid()
        Try
            'Load the Roles
            grdPermissions.DataSource = RC.GetPortalRoles(PortalSettings.PortalId)
            grdPermissions.DataBind()
            grdEditPermissions.DataSource = RC.GetPortalRoles(PortalSettings.PortalId)
            grdEditPermissions.DataBind()

            'Set Permissions after Role Load

            Dim count As Integer = 0
            Dim newRole As Boolean = False
            Dim PermissionList As TabPermissionCollection = TabPermissionController.GetTabPermissions(PortalSettings.ActiveTab.TabID, PortalSettings.PortalId)

            For Each row As GridViewRow In grdPermissions.Rows

                'Remove roles not from this portal
                If row.Cells(1).Text = "Administrators" Or row.Cells(1).Text = "Subscribers" Or _
                    row.Cells(1).Text = "Registered Users" Or row.Cells(1).Text.Contains("Translator") Or _
                    PortalSettings.PortalId <> row.Cells(2).Text Or row.Cells(1).Text.Contains("Unverified Users") Then
                    grdPermissions.Rows.Item(count).Attributes.CssStyle.Add("display", "none")
                    grdEditPermissions.Rows.Item(count).Attributes.CssStyle.Add("display", "none")
                Else
                    newRole = True
                End If

                'Remove roles this user doesn't have if they're not an administrator
                If PortalSettings.UserInfo.IsInRole("Administrators") = False Then
                    If PortalSettings.UserInfo.IsInRole(row.Cells(1).Text) = False Then
                        grdPermissions.Rows.Item(count).Attributes.CssStyle.Add("display", "none")
                        grdEditPermissions.Rows.Item(count).Attributes.CssStyle.Add("display", "none")
                    End If
                End If

                'Set Permissions of current page to this new one
                For Each TPC As TabPermissionInfo In PermissionList
                    If row.Cells(1).Text = TPC.RoleName Then
                        If TPC.PermissionID = 4 And PortalSettings.PortalId = row.Cells(2).Text Then
                            CType(row.FindControl("cbxAddEdit"), CheckBox).Checked = True
                            CType(grdEditPermissions.Rows(count).FindControl("cbxEditEdit"), CheckBox).Checked = True
                        End If
                    End If
                Next

                count = count + 1
            Next

            If newRole = False Then
                lblPermissions.Text = ""
                lblEditPermissions.Text = ""
            End If

            grdPermissions.Visible = newRole
            grdEditPermissions.Visible = newRole

            grdPermissions.HeaderRow.Visible = False
            grdPermissions.Columns(2).Visible = False 'portal id column
            grdEditPermissions.HeaderRow.Visible = False
            grdEditPermissions.Columns(2).Visible = False 'portal id column

        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        End Try
    End Sub

    Protected Sub LoadDDLs()
        Try
            'Gets Tabs based on edit permissions
            ddlAddParent.Items.Clear()

            Dim langcontroller As New Localization
            If langcontroller.CurrentCulture.Contains("fr") Then
                ddlAddParent.Items.Add(New ListItem("<Menu principal>", -1))
                ddlEditParent.Items.Add(New ListItem("<Menu principal>", -1))
            Else
                ddlAddParent.Items.Add(New ListItem("<Main Menu>", -1))
                ddlEditParent.Items.Add(New ListItem("<Main Menu>", -1))
            End If
            Dim InvalidIDs As String = "@" & PortalSettings.ActiveTab.TabID & "@"
            For Each TempTab As DotNetNuke.Entities.Tabs.TabInfo In TabController.GetPortalTabs(PortalSettings.PortalId, 0, False, "", True, False, True, False, True)
                Dim AdjustedName As String = TempTab.TabName
                Dim level As Integer = TempTab.Level
                If level <> 0 Then AdjustedName = "» " & AdjustedName
                While level > 1
                    AdjustedName = "&nbsp;&nbsp;&nbsp;&nbsp;" & AdjustedName
                    level = level - 1
                End While
                level = level - 1

                If InvalidIDs.Contains("@" & TempTab.ParentId & "@") Then
                    InvalidIDs = InvalidIDs & TempTab.TabID & "@"
                Else
                    ddlAddParent.Items.Add(New ListItem(HttpUtility.HtmlDecode(AdjustedName), TempTab.TabID))
                    If InvalidIDs.Contains("@" & TempTab.TabID & "@") Then
                        InvalidIDs = InvalidIDs & TempTab.TabID & "@"
                    Else
                        ddlEditParent.Items.Add(New ListItem(HttpUtility.HtmlDecode(AdjustedName), TempTab.TabID))
                    End If
                End If
            Next

            ddlAddParent.SelectedValue = PortalSettings.ActiveTab.TabID
            SetAddPageOrder()
            ddlEditParent.SelectedValue = PortalSettings.ActiveTab.ParentId
            SetEditPageOrder()

            'Module DDLs, this works with the DNN module drop down
            ddlModuleList.Items.Clear()
            Dim SelectedVal As Integer = 0
            For Each DMI As DesktopModuleInfo In DesktopModuleController.GetDesktopModules(PortalSettings.PortalId).Values
                If PortalSettings.UserInfo.IsInRole("Administrators") Then
                    ddlModuleList.Items.Add(New ListItem(DMI.FriendlyName, DMI.DesktopModuleID))
                Else
                    If DMI.Category = "Common" Then
                        ddlModuleList.Items.Add(New ListItem(DMI.FriendlyName, DMI.DesktopModuleID))
                    End If
                End If
                If DMI.FriendlyName.Contains("HTML") Then SelectedVal = DMI.DesktopModuleID
            Next
            ddlModuleList.SelectedValue = SelectedVal

            'TODO: Create a more friendly module selection list
            'If PortalSettings.UserInfo.IsSuperUser Then
            '    rdoModules.Items.Clear()
            '    For Each DMI As DesktopModuleInfo In DesktopModuleController.GetDesktopModules(PortalSettings.PortalId).Values
            '        Dim Image As String = Installer.Packages.PackageController.GetPackage(DMI.PackageID).IconFile.ToString.Replace("~", "")
            '        If Image.Trim = "" Then Image = "/images/appGallery_module.gif"
            '        rdoModules.Items.Add(New ListItem("<div class='float-left module-list-item margin-right-small button button-info' style='width:80px; height: 80px' onclick='javascript:radioSelected(this);'><img src='" & Image & "' style='width:32px !important;height:32px !important' /><br />" & DMI.FriendlyName & "</div>", DMI.DesktopModuleID))
            '    Next
            '    'pnlModules.Width = lstModules.Items.Count * 60
            'End If

            ddlModPane.Items.Clear()
            ddlModPane.DataSource = PortalSettings.Current.ActiveTab.Panes
            ddlModPane.DataBind()

            'For home page Intranet setup
            If PortalSettings.HomeTabId <> PortalSettings.ActiveTab.TabID And ddlModPane.Items.Contains(New ListItem("BottomLeft", "BottomLeft")) Then
                ddlModPane.Items.Remove("BottomLeft")
                ddlModPane.Items.Remove("BottomRight")
            End If

            If (PortalSettings.Current.ActiveTab.Panes.Contains(DotNetNuke.Common.Globals.glbDefaultPane)) Then
                ddlModPane.SelectedValue = DotNetNuke.Common.Globals.glbDefaultPane
            End If

        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        End Try
    End Sub

    Protected Sub LoadLanguages()
        'Admin Bar
        ddlMode.Items.Add(New ListItem(Localization.GetString("ADMINView", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc))), "VIEW"))
        ddlMode.Items.Add(New ListItem(Localization.GetString("ADMINEdit", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc))), "EDIT"))
        btnAddModule.Text = Localization.GetString("ADMINAddAModule", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnAddPage.Text = Localization.GetString("ADMINAddAPage", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnPageOptions.Text = Localization.GetString("ADMINPageSettings", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnAdministration.Text = Localization.GetString("ADMINSettings", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        pnlAddModule.ToolTip = "<div style='width:650px; float:left;'>" & Localization.GetString("ADMINAddAModule", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc))) & "</div>"
        pnlAddPage.ToolTip = "<div style='width:650px; float:left;'>" & Localization.GetString("ADMINAddAPage", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc))) & "</div>"
        pnlPageOptions.ToolTip = "<div style='width:650px; float:left;'>" & Localization.GetString("ADMINCurrentPage", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc))) & "</div>"
        pnlAdministration.ToolTip = "<div style='width:650px; float:left;'>" & Localization.GetString("ADMINOptions", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc))) & "</div>"
        btnEditCurrentSettings.Text = "<img style='margin-bottom:-4px' src='/images/action_settings.gif' /> " & Localization.GetString("ADMINSettings", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc))) & " "
        btnDeletePage.Text = " <img style='margin-bottom:-4px' src='/images/delete.gif' /> " & Localization.GetString("ADMINDelete", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))

        'Errors
        ltlErrorTitle.Text = Localization.GetString("msgErrorTitle.Text", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))

        'Admin Buttons
        btnAdminFiles.Text = Localization.GetString("ADMINDocument", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnAdminLog.Text = Localization.GetString("ADMINStats", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnAdminPages.Text = Localization.GetString("ADMINPages", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnAdminRecycle.Text = Localization.GetString("ADMINRecycle", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnAdminRoles.Text = Localization.GetString("ADMINRoles", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnAdminUsers.Text = Localization.GetString("ADMINUsers", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))

        'Add a Page
        lblAddEnd.Text = Localization.GetString("ADMINEndDate", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblAddPageName.Text = Localization.GetString("ADMINName", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblAddParent.Text = Localization.GetString("ADMINParent", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblAddStart.Text = Localization.GetString("ADMINPublish", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblPermissions.Text = Localization.GetString("ADMINPermissions", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblAddIncludeInMenu.Text = Localization.GetString("ADMINShow", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblAddVisibleToUsers.Text = Localization.GetString("ADMINVisible", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnAddSave.Text = Localization.GetString("ADMINSave", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblAddExists.Text = "<div style='padding-top:5px; color:red;'>" & Localization.GetString("ADMINExists", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc))) & "</div>"
        lblPageOrder.Text = Localization.GetString("ADMINOrder", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))

        'Module
        lblModPane.Text = Localization.GetString("ADMINPane", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblModTitle.Text = Localization.GetString("ADMINTitle", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblModule.Text = Localization.GetString("ADMINModule", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblModVisible.Text = Localization.GetString("ADMINVisible", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnModSave.Text = Localization.GetString("ADMINSave", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))

        'Page Options
        lblEditEnd.Text = Localization.GetString("ADMINEndDate", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblEditPageName.Text = Localization.GetString("ADMINName", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblEditParent.Text = Localization.GetString("ADMINParent", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblEditStart.Text = Localization.GetString("ADMINPublish", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblEditPermissions.Text = Localization.GetString("ADMINPermissions", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblEditIncludeInMenu.Text = Localization.GetString("ADMINShow", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblEditVisibleToUsers.Text = Localization.GetString("ADMINVisible", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnEditSave.Text = Localization.GetString("ADMINSave", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblEditExists.Text = "<div style='padding-top:5px; color:red;'>" & Localization.GetString("ADMINExists", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc))) & "</div>"
        lblEditOrder.Text = Localization.GetString("ADMINOrder", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
    End Sub

    Protected Sub rdoMode_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlMode.SelectedIndexChanged
        ViewState.Clear()
        SetUserMode(ddlMode.SelectedValue)
        Response.Redirect(PortalSettings.ActiveTab.FullUrl)
    End Sub

    Protected Sub GetHostViewTabs()

        'Show the admin and host pages
        Dim CellCount As Integer = 2
        Dim Row As New TableRow
        Dim HeaderRow As New TableHeaderRow
        Dim HeaderCell As New TableHeaderCell
        Dim Cell As New TableCell

        HeaderCell.ColumnSpan = 2
        If PortalSettings.UserInfo.IsSuperUser Then HeaderCell.Text = "<a href='/admin.aspx'><b>Admin</b></a>"
        HeaderRow.Cells.Add(HeaderCell)
        tblHost.Rows.Add(HeaderRow)

        'Admin Pages
        For Each TempTab As DotNetNuke.Entities.Tabs.TabInfo In DotNetNuke.Entities.Tabs.TabController.GetTabsByParent(PortalSettings.AdminTabId, PortalSettings.PortalId)

            If TempTab.IsDeleted = False And TempTab.IsVisible Then

                Cell = New TableCell

                If CellCount = 2 Then
                    tblHost.Rows.Add(Row)
                    Row = New TableRow
                    CellCount = 0
                End If

                Cell.Text = "<a href='http://" & PortalSettings.PortalAlias.HTTPAlias & TempTab.TabPath.Replace("//", "/") & ".aspx'>" & TempTab.TabName & "</a>"

                If TempTab.IconFile = "" Then
                    Cell.Text = "<img src='/Icons/Sigma/File_16x16_Standard.png' />" & Cell.Text
                Else
                    Cell.Text = "<img src='" & TempTab.IconFile & "' />" & Cell.Text
                End If

                Cell.Text = Cell.Text.Replace("~", "")

                If PortalSettings.UserInfo.IsSuperUser Then
                    Row.Cells.Add(Cell)
                    CellCount = CellCount + 1
                Else
                    If TempTab.CreatedByUserID <> -1 Then
                        Row.Cells.Add(Cell)
                        CellCount = CellCount + 1
                    End If
                End If

            End If

        Next

        tblHost.Rows.Add(Row)


        If PortalSettings.UserInfo.IsSuperUser Then
            Dim HostTab As DotNetNuke.Entities.Tabs.TabInfo = TC.GetTabByName("Host", "-1")
            CellCount = 2
            Row = New TableRow
            Cell = New TableCell
            HeaderRow = New TableHeaderRow
            HeaderCell = New TableHeaderCell

            HeaderCell.ColumnSpan = 2
            If PortalSettings.UserInfo.IsSuperUser Then HeaderCell.Text = "<a href='/host.aspx'><b>Host</b></a>"
            HeaderRow.Cells.Add(HeaderCell)
            tblHost.Rows.Add(HeaderRow)

            'Host Pages
            For Each TempTab As DotNetNuke.Entities.Tabs.TabInfo In DotNetNuke.Entities.Tabs.TabController.GetTabsByParent(HostTab.TabID, "-1")

                If TempTab.IsDeleted = False And TempTab.IsVisible Then

                    Cell = New TableCell

                    If CellCount = 2 Then
                        tblHost.Rows.Add(Row)
                        Row = New TableRow
                        CellCount = 0
                    End If

                    Cell.Text = "<a href='http://" & PortalSettings.PortalAlias.HTTPAlias & TempTab.TabPath.Replace("//", "/") & ".aspx'>" & TempTab.TabName & "</a>"

                    If TempTab.IconFile = "" Then
                        Cell.Text = "<img src='/Icons/Sigma/File_16x16_Standard.png' />" & Cell.Text
                    Else
                        Cell.Text = "<img src='" & TempTab.IconFile & "' />" & Cell.Text
                    End If

                    Cell.Text = Cell.Text.Replace("~", "")

                    Row.Cells.Add(Cell)

                    CellCount = CellCount + 1

                End If

            Next

            tblHost.Rows.Add(Row)

        End If

    End Sub

    Protected Sub btnAdminUsers_Click(sender As Object, e As System.EventArgs) Handles btnAdminUsers.Click
        Response.Redirect("http://" & PortalSettings.PortalAlias.HTTPAlias & "/Admin/UserAccounts.aspx")
    End Sub

    Protected Sub btnAdminFiles_Click(sender As Object, e As System.EventArgs) Handles btnAdminFiles.Click
        Response.Redirect("http://" & PortalSettings.PortalAlias.HTTPAlias & "/Admin/FileManager.aspx")
    End Sub

    Protected Sub btnAdminLog_Click(sender As Object, e As System.EventArgs) Handles btnAdminLog.Click
        Response.Redirect("http://" & PortalSettings.PortalAlias.HTTPAlias & "/Admin/SiteLog.aspx")
    End Sub

    Protected Sub btnAdminPages_Click(sender As Object, e As System.EventArgs) Handles btnAdminPages.Click
        Response.Redirect("http://" & PortalSettings.PortalAlias.HTTPAlias & "/Admin/Pages.aspx")
    End Sub

    Protected Sub btnAdminRecycle_Click(sender As Object, e As System.EventArgs) Handles btnAdminRecycle.Click
        Response.Redirect("http://" & PortalSettings.PortalAlias.HTTPAlias & "/Admin/RecycleBin.aspx")
    End Sub

    Protected Sub btnAdminRoles_Click(sender As Object, e As System.EventArgs) Handles btnAdminRoles.Click
        Response.Redirect("http://" & PortalSettings.PortalAlias.HTTPAlias & "/Admin/SecurityRoles.aspx")
    End Sub

    Protected Sub btnHdnAddSave_Click(sender As Object, e As System.EventArgs) Handles btnHdnAddSave.Click
        Try
            'Create the new page
            Dim TempTab As New DotNetNuke.Entities.Tabs.TabInfo
            TempTab.PortalID = PortalSettings.PortalId
            TempTab.TabName = txtAddPageName.Text
            TempTab.Title = txtAddPageName.Text
            TempTab.IsVisible = cbxAddIncludeInMenu.Checked
            TempTab.IsDeleted = False
            TempTab.IsSuperTab = False
            TempTab.ParentId = ddlAddParent.SelectedValue

            'Add the publish dates
            TempTab.StartDate = Nothing
            TempTab.EndDate = Nothing
            If IsDate(dateAddStart.SelectedDate) Then TempTab.StartDate = dateAddStart.SelectedDate
            If IsDate(dateAddEnd.SelectedDate) Then TempTab.EndDate = dateAddEnd.SelectedDate

            'Add the hyperlink 'Currently Hidden
            'If txtAddLink.Text.Trim <> "" And txtAddLink.Text.Length > 4 Then
            '    If txtAddLink.Text.Substring(0, 4) = "http" Then
            '        TempTab.Url = txtAddLink.Text.Trim
            '    Else
            '        TempTab.Url = "http://" & txtAddLink.Text.Trim
            '    End If
            'End If

            Dim NewTabId As Integer
            NewTabId = TC.AddTab(TempTab)

            'Page Order
            If ddlPageOrder.Items.Count > 0 Then
                If ddlPageOrder.SelectedItem.Text.StartsWith("Before") Or ddlPageOrder.SelectedItem.Text.StartsWith("Avant") Then
                    TC.MoveTabBefore(TempTab, ddlPageOrder.SelectedValue)
                Else
                    TC.MoveTabAfter(TempTab, ddlPageOrder.SelectedValue)
                End If
            End If

            'Multilingual Title
            Dim LangController As New LocaleController
            Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name
            If LangController.GetDefaultLocale(PortalSettings.ActiveTab.PortalID).Code <> ThisLocale Then
                TC.UpdateTabSetting(NewTabId, "PageTitle" & ThisLocale, txtAddPageName.Text)
            End If

            'Get the new tab and add permissions to it
            Dim NewTab As New DotNetNuke.Entities.Tabs.TabInfo
            NewTab = TC.GetTab(NewTabId, PortalSettings.PortalId, True)

            Dim PermissionProvider As New DotNetNuke.Security.Permissions.PermissionProvider

            'Clear the old Permissions
            While NewTab.TabPermissions.Count > 0
                NewTab.TabPermissions.RemoveAt(0)
            End While

            'View Permissions
            If cbxAddVisibleToUsers.Checked Then
                Dim TabPermission As New DotNetNuke.Security.Permissions.TabPermissionInfo
                TabPermission.TabID = NewTabId
                TabPermission.AllowAccess = True
                TabPermission.PermissionID = 3 'VIEW
                TabPermission.RoleID = -1 'All Users  
                NewTab.TabPermissions.Add(TabPermission, True)
            End If

            'Edit Permissions
            For Each row As GridViewRow In grdPermissions.Rows
                If CType(row.FindControl("cbxAddEdit"), CheckBox).Checked Then
                    Dim TempRole As DotNetNuke.Security.Roles.RoleInfo
                    TempRole = RC.GetRoleByName(PortalSettings.PortalId, row.Cells(1).Text)

                    Dim TabPermission As New DotNetNuke.Security.Permissions.TabPermissionInfo
                    TabPermission.TabID = NewTabId
                    TabPermission.AllowAccess = True
                    TabPermission.PermissionID = 4 'EDIT
                    TabPermission.RoleID = TempRole.RoleID
                    NewTab.TabPermissions.Add(TabPermission, True)

                    TabPermission = New DotNetNuke.Security.Permissions.TabPermissionInfo
                    TabPermission.TabID = NewTabId
                    TabPermission.AllowAccess = True
                    TabPermission.PermissionID = 3 'VIEW
                    TabPermission.RoleID = TempRole.RoleID
                    NewTab.TabPermissions.Add(TabPermission, True)
                End If
            Next

            PermissionProvider.SaveTabPermissions(NewTab)
            DataCache.ClearTabPermissionsCache(PortalSettings.PortalId)

            'This ensures only Admins can set visibility of the menu by default for the first 3 levels in any skin with SECMENU in it
            If UI.Skins.Skin.GetSkin(Me.Page).ToString.ToUpper.Contains("SECMENU") Then
                If PortalSettings.UserInfo.IsInRole("Administrators") Or TempTab.Level > 2 Then
                Else
                    NewTab.IsVisible = False
                    TC.UpdateTab(NewTab)
                End If
            End If

            Response.Redirect(NewTab.FullUrl)
        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        End Try
    End Sub

    Protected Sub btnHdnEditSave_Click(sender As Object, e As System.EventArgs) Handles btnHdnEditSave.Click
        Try
            'Create the new page
            Dim TempTab As New DotNetNuke.Entities.Tabs.TabInfo
            TempTab = PortalSettings.ActiveTab

            'This ensures only Admins can update visibility of the menu by default for the first 3 levels in any skin with SECMENU in it
            If UI.Skins.Skin.GetSkin(Me.Page).ToString.ToUpper.Contains("SECMENU") Then
                If PortalSettings.UserInfo.IsInRole("Administrators") Or TempTab.Level > 2 Then
                    TempTab.IsVisible = cbxEditIncludeInMenu.Checked
                End If
            Else
                TempTab.IsVisible = cbxEditIncludeInMenu.Checked
            End If

            TempTab.ParentId = ddlEditParent.SelectedValue
            TempTab.SkinSrc = TempTab.SkinSrc.Replace("/Portals/_default/", "[G]")
            TempTab.ContainerSrc = TempTab.ContainerSrc.Replace("/Portals/_default/", "[G]")

            'Add the publish dates
            If IsDate(dateEditStart.SelectedDate) Then
                If DateTime.Parse(dateEditStart.SelectedDate).Year > 1990 & _
                    DateTime.Parse(dateEditStart.SelectedDate).Year < 2100 Then
                    TempTab.StartDate = dateEditStart.SelectedDate
                Else
                    TempTab.StartDate = Nothing
                End If
            Else
                TempTab.StartDate = Nothing
            End If
            If IsDate(dateEditEnd.SelectedDate) Then
                If DateTime.Parse(dateEditEnd.SelectedDate).Year > 1990 & _
                    DateTime.Parse(dateEditEnd.SelectedDate).Year < 2100 Then
                    TempTab.EndDate = dateEditEnd.SelectedDate
                Else
                    TempTab.EndDate = Nothing
                End If
            Else
                TempTab.EndDate = Nothing
            End If

            'Add the hyperlink
            'If txtEditLink.Text.Trim <> "" And txtEditLink.Text.Length > 4 Then
            '    If txtEditLink.Text.Substring(0, 4) = "http" Then
            '        TempTab.Url = txtEditLink.Text.Trim
            '    Else
            '        TempTab.Url = "http://" & txtEditLink.Text.Trim
            '    End If
            'End If

            'Multilingual Title
            Dim LangController As New LocaleController
            Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name
            If LangController.GetDefaultLocale(PortalSettings.ActiveTab.PortalID).Code <> ThisLocale Then
                TC.UpdateTabSetting(PortalSettings.ActiveTab.TabID, "PageTitle" & ThisLocale, txtEditPageName.Text)
            Else
                TempTab.TabName = txtEditPageName.Text
                TempTab.Title = txtEditPageName.Text
                TempTab.TabPath = TempTab.TabPath.Substring(0, TempTab.TabPath.LastIndexOf("//")) & "//" & Regex.Replace(txtEditPageName.Text, "[^A-Za-z0-9_-]", "")
            End If

            TC.UpdateTab(TempTab)

            'Page Order
            If ddlEditOrder.Items.Count > 0 Then
                If ddlEditOrder.SelectedItem.Text.StartsWith("Before") Or ddlEditOrder.SelectedItem.Text.StartsWith("Avant") Then
                    TC.MoveTabBefore(TempTab, ddlEditOrder.SelectedValue)
                Else
                    TC.MoveTabAfter(TempTab, ddlEditOrder.SelectedValue)
                End If
            End If

            Dim PermissionProvider As New DotNetNuke.Security.Permissions.PermissionProvider
            ''Clear the old Permissions
            'While TempTab.TabPermissions.Count > 0
            '    TempTab.TabPermissions.RemoveAt(0)
            'End While

            Try

                Dim PermissionCount As Integer = TempTab.TabPermissions.Count
                While PermissionCount > 0
                    PermissionCount = PermissionCount - 1
                    'Remove View permission
                    If TempTab.TabPermissions.Item(PermissionCount).RoleID = -1 And TempTab.TabPermissions.Item(PermissionCount).PermissionID = 3 Then
                        TempTab.TabPermissions.RemoveAt(PermissionCount)
                    End If
                    'Remove Edit Permissions that are available


                    If TempTab.TabPermissions.Item(PermissionCount).PermissionID = 4 Then
                        For Each row As GridViewRow In grdEditPermissions.Rows
                            'This won't work on roles with special characters, which aren't allowed by default but the AD role syncer will
                            Try
                                If CType(row.FindControl("cbxEditEdit"), CheckBox).Checked = False And _
                                    RC.GetRoleByName(PortalSettings.PortalId, row.Cells(1).Text).RoleID = TempTab.TabPermissions.Item(PermissionCount).RoleID Then
                                    TempTab.TabPermissions.RemoveAt(PermissionCount)
                                End If
                            Catch ex As Exception

                            End Try
                        Next
                    End If


                End While

            Catch ex As Exception

            End Try

            'View Permissions
            If cbxEditVisibleToUsers.Checked Then
                Dim TabPermission As New DotNetNuke.Security.Permissions.TabPermissionInfo
                TabPermission.TabID = TempTab.TabID
                TabPermission.AllowAccess = True
                TabPermission.PermissionID = 3 'VIEW
                TabPermission.RoleID = -1 'All Users  
                TempTab.TabPermissions.Add(TabPermission, True)
            End If

            'Edit Permissions
            For Each row As GridViewRow In grdEditPermissions.Rows
                If CType(row.FindControl("cbxEditEdit"), CheckBox).Checked Then
                    Dim TempRole As DotNetNuke.Security.Roles.RoleInfo
                    TempRole = RC.GetRoleByName(PortalSettings.PortalId, row.Cells(1).Text)

                    Dim TabPermission As New DotNetNuke.Security.Permissions.TabPermissionInfo
                    TabPermission.TabID = TempTab.TabID
                    TabPermission.AllowAccess = True
                    TabPermission.PermissionID = 4 'EDIT
                    TabPermission.RoleID = TempRole.RoleID
                    TempTab.TabPermissions.Add(TabPermission, True)

                    TabPermission = New DotNetNuke.Security.Permissions.TabPermissionInfo
                    TabPermission.TabID = TempTab.TabID
                    TabPermission.AllowAccess = True
                    TabPermission.PermissionID = 3 'VIEW
                    TabPermission.RoleID = TempRole.RoleID
                    TempTab.TabPermissions.Add(TabPermission, True)
                End If
            Next

            PermissionProvider.SaveTabPermissions(TempTab)
            DataCache.ClearTabPermissionsCache(PortalSettings.PortalId)
            DataCache.ClearTabsCache(PortalSettings.PortalId)

            Response.Redirect(TC.GetTab(TempTab.TabID, TempTab.PortalID, True).FullUrl)
        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        End Try
    End Sub

    Protected Sub DoAddNewModule(title As String, desktopModuleId As Integer, paneName As String, position As Integer, permissionType As Boolean)
        Dim objTabPermissions As TabPermissionCollection = PortalSettings.Current.ActiveTab.TabPermissions
        Dim objPermissionController = New PermissionController()
        Dim objModules As New ModuleController

        For Each objModuleDefinition As ModuleDefinitionInfo In ModuleDefinitionController.GetModuleDefinitionsByDesktopModuleID(desktopModuleId).Values
            Dim objModule = New ModuleInfo()
            objModule.Initialize(PortalSettings.Current.PortalId)

            objModule.PortalID = PortalSettings.Current.PortalId
            objModule.TabID = PortalSettings.Current.ActiveTab.TabID
            objModule.ModuleOrder = position
            objModule.ModuleTitle = If(String.IsNullOrEmpty(title), objModuleDefinition.FriendlyName, title)
            objModule.PaneName = paneName
            objModule.ModuleDefID = objModuleDefinition.ModuleDefID
            If objModuleDefinition.DefaultCacheTime > 0 Then
                objModule.CacheTime = objModuleDefinition.DefaultCacheTime
                If PortalSettings.Current.DefaultModuleId > Null.NullInteger AndAlso PortalSettings.Current.DefaultTabId > Null.NullInteger Then
                    Dim defaultModule As ModuleInfo = objModules.GetModule(PortalSettings.Current.DefaultModuleId, PortalSettings.Current.DefaultTabId, True)
                    If (defaultModule IsNot Nothing) Then
                        objModule.CacheTime = defaultModule.CacheTime
                    End If
                End If
            End If

            objModule.InheritViewPermissions = permissionType

            If PortalSettings.Current.ContentLocalizationEnabled Then
                Dim defaultLocale As Locale = LocaleController.Instance.GetDefaultLocale(PortalSettings.Current.PortalId)
                objModule.CultureCode = defaultLocale.Code
            Else
                objModule.CultureCode = Null.NullString
            End If
            objModule.AllTabs = False
            objModule.Alignment = ""

            Dim newMod As Integer = objModules.AddModule(objModule)

            'Multilingual
            Dim LangController As New LocaleController
            Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name
            If LangController.GetDefaultLocale(PortalSettings.PortalId).Code <> ThisLocale Then
                objModules.UpdateModuleSetting(newMod, "ModuleTitle" & ThisLocale, title)
            End If

            'Update the permissions
            'Edit Permissions
            objModule = objModules.GetModule(newMod)

            Dim TempGrid As New GridView
            TempGrid.DataSource = RC.GetPortalRoles(PortalSettings.PortalId)
            TempGrid.DataBind()

            Dim PermissionList As TabPermissionCollection = TabPermissionController.GetTabPermissions(PortalSettings.ActiveTab.TabID, PortalSettings.PortalId)

            'Add Admin role
            Dim TempRole As DotNetNuke.Security.Roles.RoleInfo
            TempRole = RC.GetRoleByName(PortalSettings.PortalId, "Administrators")

            Dim ModPermission As New ModulePermissionInfo
            ModPermission.ModuleID = newMod
            ModPermission.AllowAccess = True
            ModPermission.PermissionID = 2 'EDIT
            ModPermission.RoleID = TempRole.RoleID
            objModule.ModulePermissions.Add(ModPermission, True)

            ModPermission = New ModulePermissionInfo
            ModPermission.ModuleID = newMod
            ModPermission.AllowAccess = True
            ModPermission.PermissionID = 1 'VIEW
            ModPermission.RoleID = TempRole.RoleID
            objModule.ModulePermissions.Add(ModPermission, True)

            For Each row As GridViewRow In TempGrid.Rows

                'Set Permissions of current module to this page
                For Each TPC As TabPermissionInfo In PermissionList
                    If row.Cells(9).Text = TPC.RoleName Then
                        If TPC.PermissionID = 4 Then
                            TempRole = New DotNetNuke.Security.Roles.RoleInfo
                            TempRole = RC.GetRoleByName(PortalSettings.PortalId, TPC.RoleName)

                            If PortalSettings.PortalId = TempRole.PortalID Then
                                ModPermission = New ModulePermissionInfo
                                ModPermission.ModuleID = newMod
                                ModPermission.AllowAccess = True
                                ModPermission.PermissionID = 2 'EDIT
                                ModPermission.RoleID = TempRole.RoleID
                                objModule.ModulePermissions.Add(ModPermission, True)

                                ModPermission = New ModulePermissionInfo
                                ModPermission.ModuleID = newMod
                                ModPermission.AllowAccess = True
                                ModPermission.PermissionID = 1 'VIEW
                                ModPermission.RoleID = TempRole.RoleID
                                objModule.ModulePermissions.Add(ModPermission, True)
                            End If
                        End If
                    End If
                Next

            Next

            Dim PermissionProvider As New DotNetNuke.Security.Permissions.PermissionProvider
            PermissionProvider.SaveModulePermissions(objModule)
            DataCache.ClearModulePermissionsCache(objModule.TabID)
        Next

    End Sub

    Protected Sub btnModSave_Click(sender As Object, e As System.EventArgs) Handles btnModSave.Click
        Try
            DoAddNewModule(txtModTitle.Text, ddlModuleList.SelectedValue, ddlModPane.SelectedValue, "-1", cbxModVisible.Checked)
            Response.Redirect(PortalSettings.ActiveTab.FullUrl)
        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        End Try
    End Sub

    Protected Sub ddlAddParent_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlAddParent.SelectedIndexChanged
        SetAddPageOrder()
    End Sub

    Protected Sub SetAddPageOrder()
        Try

            ddlPageOrder.Items.Clear()

            Dim langcontroller As New Localization

            For Each TempTab As DotNetNuke.Entities.Tabs.TabInfo In DotNetNuke.Entities.Tabs.TabController.GetTabsByParent(ddlAddParent.SelectedValue, PortalSettings.PortalId)

                If TempTab.IsDeleted = False Then

                    If ddlPageOrder.Items.Count = 0 Then
                        If langcontroller.CurrentCulture.Contains("fr") Then
                            ddlPageOrder.Items.Add(New ListItem("Avant " & TempTab.TabName, TempTab.TabID))
                        Else
                            ddlPageOrder.Items.Add(New ListItem("Before " & TempTab.TabName, TempTab.TabID))
                        End If
                    End If

                    If langcontroller.CurrentCulture.Contains("fr") Then
                        ddlPageOrder.Items.Add(New ListItem("Après " & TempTab.TabName, TempTab.TabID))
                    Else
                        ddlPageOrder.Items.Add(New ListItem("After " & TempTab.TabName, TempTab.TabID))
                    End If

                End If

            Next

        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        End Try
    End Sub

    Protected Sub SetEditPageOrder()
        Try

            ddlEditOrder.Items.Clear()

            Dim langcontroller As New Localization

            Dim Index As Integer = 0
            Dim Selected As Integer = 0

            For Each TempTab As DotNetNuke.Entities.Tabs.TabInfo In DotNetNuke.Entities.Tabs.TabController.GetTabsByParent(ddlEditParent.SelectedValue, PortalSettings.PortalId)

                If TempTab.IsDeleted = False Then

                    If TempTab.TabID <> PortalSettings.ActiveTab.TabID Then

                        If ddlEditOrder.Items.Count = 0 Then
                            If langcontroller.CurrentCulture.Contains("fr") Then
                                ddlEditOrder.Items.Add(New ListItem("Avant " & TempTab.TabName, TempTab.TabID))
                            Else
                                ddlEditOrder.Items.Add(New ListItem("Before " & TempTab.TabName, TempTab.TabID))
                            End If
                        End If

                        If langcontroller.CurrentCulture.Contains("fr") Then
                            ddlEditOrder.Items.Add(New ListItem("Après " & TempTab.TabName, TempTab.TabID))
                        Else
                            ddlEditOrder.Items.Add(New ListItem("After " & TempTab.TabName, TempTab.TabID))
                        End If
                        Index = Index + 1

                        If TempTab.TabOrder < PortalSettings.ActiveTab.TabOrder Then
                            Selected = Index
                        End If

                    End If

                End If

            Next

            ddlEditOrder.SelectedIndex = Selected


        Catch ex As Exception
            AddMessage(ex.Message, "Error")
            DotNetNuke.Services.Exceptions.LogException(ex)
        End Try
    End Sub

    Protected Sub ddlEditParent_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlEditParent.SelectedIndexChanged
        SetEditPageOrder()
    End Sub


End Class
