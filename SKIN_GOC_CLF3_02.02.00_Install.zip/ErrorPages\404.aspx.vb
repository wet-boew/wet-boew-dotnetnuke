﻿Imports DotNetNuke.Entities.Tabs

Partial Class Portals__default_Skins_CLF3_ErrorPages_404
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Dim portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings()
        Dim RootPath As String = portalSettings.ActiveTab.SkinPath
        SetLocalization(RootPath, portalSettings)

        'Handle the 404 Error
        Dim TC As New TabController()

        Dim ErrorMessage As String = ""

        'Get the Page Name
        Dim PageName As String = Request.QueryString("aspxerrorpath")
        If Not String.IsNullOrEmpty(PageName) Then
            If PageName.LastIndexOf("/") >= 0 Then
                PageName = PageName.Substring(PageName.LastIndexOf("/") + 1)
            End If
            PageName = PageName.Replace(".aspx", "")
        End If

        'Find similar Pages to show
        For Each T As TabInfo In TabController.GetPortalTabs(portalSettings.PortalId, -1, False, "", True, False, True, True, True)
            If Regex.Replace(T.TabPath.Substring(T.TabPath.LastIndexOf("/")), "[^A-Za-z0-9]", "").ToLower.Contains(Regex.Replace(PageName, "[^A-Za-z0-9]", "").ToLower) Then
                'Check if the page should be displayed
                If T.IsDeleted = False Then
                    ErrorMessage = ErrorMessage & "<a href='" & T.FullUrl & "'>" & T.TabName & "</a><br />"
                End If
            End If
        Next

        If ErrorMessage <> "" Then
            ErrorMessage = Localization.GetString("ERROR404.Text", RootPath + Localization.LocalResourceDirectory + "/" + System.IO.Path.GetFileName(Server.MapPath(portalSettings.ActiveTab.SkinSrc))) & "<p class='indent-large'>" & ErrorMessage & "</p>"
            ErrorMessage = "<div class='module-info module-simplify span-8'>" & ErrorMessage & "</div><div class='clear'></div>"
        End If

        ltlError.Text = ErrorMessage
    End Sub

    Protected Sub SetLocalization(ByVal RootPath As String, ByVal portalSettings As PortalSettings)
        'Set the primary skin objects
        ltlSkipToMain.Text = Localization.GetString("SKINMenuMain.Text", RootPath + Localization.LocalResourceDirectory + "/" + System.IO.Path.GetFileName(Server.MapPath(portalSettings.ActiveTab.SkinSrc)))
        ltlSkipToFooter.Text = Localization.GetString("SKINPrimaryNav.Text", RootPath + Localization.LocalResourceDirectory + "/" + System.IO.Path.GetFileName(Server.MapPath(portalSettings.ActiveTab.SkinSrc)))
        ltlGovCanada.Text = Localization.GetString("SKINGovCan.Text", RootPath + Localization.LocalResourceDirectory + "/" + System.IO.Path.GetFileName(Server.MapPath(portalSettings.ActiveTab.SkinSrc)))
        ltlSymCanada.Text = Localization.GetString("SKINSymCan.Text", RootPath + Localization.LocalResourceDirectory + "/" + System.IO.Path.GetFileName(Server.MapPath(portalSettings.ActiveTab.SkinSrc)))
        ltlSiteTitle.Text = Localization.GetString("SKINBannerTitle.Text", RootPath + Localization.LocalResourceDirectory + "/" + System.IO.Path.GetFileName(Server.MapPath(portalSettings.ActiveTab.SkinSrc)))
        ltlFooter.Text = Localization.GetString("SKINSiteFooter.Text", RootPath + Localization.LocalResourceDirectory + "/" + System.IO.Path.GetFileName(Server.MapPath(portalSettings.ActiveTab.SkinSrc)))
        ltlTermsAndConditions.Text = Localization.GetString("SKINTerms.Text", RootPath + Localization.LocalResourceDirectory + "/" + System.IO.Path.GetFileName(Server.MapPath(portalSettings.ActiveTab.SkinSrc)))
        ltlHome.Text = Localization.GetString("SKINHome.Text", RootPath + Localization.LocalResourceDirectory + "/" + System.IO.Path.GetFileName(Server.MapPath(portalSettings.ActiveTab.SkinSrc)))
        ltlContact.Text = Localization.GetString("SKINContact.Text", RootPath + Localization.LocalResourceDirectory + "/" + System.IO.Path.GetFileName(Server.MapPath(portalSettings.ActiveTab.SkinSrc)))
        ltlMessageH1.Text = Localization.GetString("ERROR404Title.Text", RootPath + Localization.LocalResourceDirectory + "/" + System.IO.Path.GetFileName(Server.MapPath(portalSettings.ActiveTab.SkinSrc)))
        ltlMessageH2.Text = Localization.GetString("ERROR404Title.Text", RootPath + Localization.LocalResourceDirectory + "/" + System.IO.Path.GetFileName(Server.MapPath(portalSettings.ActiveTab.SkinSrc)))
    End Sub

End Class
