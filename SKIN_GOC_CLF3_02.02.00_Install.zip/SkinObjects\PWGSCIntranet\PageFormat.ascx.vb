﻿Imports DotNetNuke.Entities.Modules
Partial Class Portals__default_Skins_CLF3___DNN6_Skin_Objects_PageFormat
    Inherits DotNetNuke.UI.Skins.SkinObjectBase

    Dim TC As New DotNetNuke.Entities.Tabs.TabController
    Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        'Check if this is the splash page
        If PortalSettings.SplashTabId = PortalSettings.ActiveTab.TabID Then
            FEGC.StyleSheet = "/build/theme-gcwu-fegc/css/theme-sp-pe-min.css"
            FEGCIE.StyleSheet = "/build/theme-gcwu-fegc/css/theme-sp-pe-ie-min.css"
            noscriptCSS.Attributes.Remove("href")
            noscriptCSS.Attributes.Add("href", "/build/theme-gcwu-fegc/css/theme-ns-min.css")
        End If

        'Check for non IE browsers
        If Request.Browser.Type <> "IE" Then
            Util.Condition = ""
            PE.Condition = ""
            FEGC.Condition = ""
            INTRANET.Condition = ""
        End If

        Dim MC As New ModuleController

        Try
            'Get the page name for metadata
            Dim hash As Hashtable = TC.GetTabSettings(PortalSettings.ActiveTab.TabID)
            If String.IsNullOrEmpty(hash("PageTitle" & ThisLocale)) Then
                SetMetaData(PortalSettings.ActiveTab.TabName)
            Else
                SetMetaData(hash("PageTitle" & ThisLocale).ToString)
            End If

        Catch ex As Exception
            If PortalSettings.UserInfo.IsSuperUser Then Response.Write("Page Format: " & ex.Message)
        End Try
    End Sub

    Protected Sub SetMetaData(ByVal Title As String)
        'MetaData
        'Title isn't used right now
        SetMeta("description", PortalSettings.Description, "")
        SetMeta("dcterms.creator", PortalSettings.FooterText, "")
        SetMeta("dcterms.title", Title, "")
        SetMeta("dcterms.issued", PortalSettings.CreatedOnDate.ToString, "W3CDTF")
        SetMeta("dcterms.modified", PortalSettings.LastModifiedOnDate.ToString, "W3CDTF")
        SetMeta("dcterms.subject", PortalSettings.KeyWords, "gccore")
        SetMeta("dcterms.language", "fra||eng", "ISO639-2")
        SetMeta("viewport", "width=device-width, initial-scale=1", "")
    End Sub

    Protected Sub SetMeta(ByVal Name As String, ByVal Description As String, ByVal Title As String)
        Try

            Dim meta As HtmlMeta = New HtmlMeta
            meta = New HtmlMeta
            meta.Name = Name

            'The french and english are split up by ||
            If Description.Contains("||") Then
                If ThisLocale.ToUpper().Contains("FR") Then
                    meta.Content = Description.Substring(0, Description.IndexOf("||"))
                Else
                    meta.Content = Description.Substring(Description.IndexOf("||") + 2)
                End If
            Else
                meta.Content = Description
            End If
            Page.Header.Controls.Add(meta)

        Catch ex As Exception
            If PortalSettings.UserInfo.IsSuperUser Then Response.Write("Setting Metadata Error: " & ex.Message)
        End Try
    End Sub


End Class
