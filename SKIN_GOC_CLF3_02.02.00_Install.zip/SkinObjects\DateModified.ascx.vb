﻿
Partial Class Portals__default_Skins_CLF_Skin_Skin_Objects_DateModified
    Inherits DotNetNuke.UI.Skins.SkinObjectBase

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Using connection As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("SiteSqlServer").ToString)
                Dim command As New SqlCommand
                'Add a line to this if you want to have another module checked
                command.CommandText = "DECLARE @Other VARCHAR(100) " & _
                                    "IF EXISTS (SELECT name FROM sysobjects WHERE name = 'EventsCalendar' AND type = 'U') " & _
                                    "BEGIN " & _
                                    "	SET @Other = (SELECT TOP 1 HT.CreatedDate AS 'OrderDate' FROM [EventsCalendar] HT JOIN vw_Modules V ON V.ModuleID = HT.ModuleID WHERE V.TabId = @TabID AND IsDeleted = 0) " & _
                                    "END " & _
                                    "SELECT LastModifiedOnDate AS 'OrderDate' FROM vw_Tabs WHERE TabID = @TabID  " & _
                                    "UNION SELECT LastModifiedOnDate AS 'OrderDate' FROM TabModules WHERE TabID = @TabID  " & _
                                    "UNION SELECT LastModifiedOnDate AS 'OrderDate' FROM [vw_Modules] WHERE TabId = @TabID AND IsDeleted = 0  " & _
                                    "UNION SELECT HT.LastModifiedOnDate AS 'OrderDate' FROM [HtmlText] HT JOIN vw_Modules V ON V.ModuleID = HT.ModuleID WHERE V.TabId = @TabID AND IsDeleted = 0   " & _
                                    "UNION SELECT @Other AS 'OrderDate' " & _
                                    "ORDER BY OrderDate DESC"
                command.Parameters.AddWithValue("@TabID", PortalSettings.ActiveTab.TabID)
                command.Connection = connection
                Try
                    command.Connection.Open()
                    Dim reader As SqlDataReader = command.ExecuteReader
                    Dim count As Integer = 0
                    If reader.HasRows Then
                        While reader.Read And count = 0
                            If reader.Item(0).ToString <> "" Then
                                Dim UpdatedOn As Date
                                UpdatedOn = reader.Item(0)
                                lblDateMod.Text = CDate(UpdatedOn).ToString("yyyy-MM-dd")
                                count = count + 1
                            End If
                        End While
                    End If
                Finally
                    command.Connection.Close()
                End Try

                If lblDateMod.Text.Trim = "" Then
                    'No database rows were found, empty page
                    lblDateMod.Text = Today.ToString("yyyy-MM-dd")
                End If

                'Show Page Visits if the process exists
                If IsEditMode() Then
                    command = New SqlCommand
                    command.CommandText = "SELECT REPLACE([SettingName],'PageVisitsTo','') AS 'ToDate',[SettingValue] as 'Hits', CreatedOnDate FROM [dbo].[TabSettings]  WHERE SettingName like 'PageVisitsTo%' AND TabID = @TabID " & _
                                          "UNION ALL " & _
                                          "SELECT CAST(GETDATE() AS VARCHAR(50)) AS 'ToDate', COUNT(*) as 'Hits', GETDATE() AS 'CreatedOnDate' FROM SiteLog WHERE TabID = @TabID Order By CreatedOnDate"
                    command.Parameters.AddWithValue("@TabID", PortalSettings.ActiveTab.TabID)
                    command.Connection = connection
                    Dim Visits As String = ""
                    Try
                        command.Connection.Open()
                        Dim reader As SqlDataReader = command.ExecuteReader
                        Dim count As Integer = 0
                        If reader.HasRows Then
                            While reader.Read And count = 0
                                Visits = Visits & "<br />" & reader.Item("Hits").ToString & " page visits to " & FormatDateTime(reader.Item("ToDate").ToString, DateFormat.LongDate)
                            End While
                            lblDateMod.Text = lblDateMod.Text & Visits
                        End If
                    Finally
                        command.Connection.Close()
                    End Try
                End If
            End Using
        Catch ex As Exception
            If PortalSettings.UserInfo.IsSuperUser Then Response.Write("Date Modified Error: " & ex.Message)
        Finally
            lblDateMod.Text = Today.ToString("yyyy-MM-dd")
        End Try
    End Sub

End Class
