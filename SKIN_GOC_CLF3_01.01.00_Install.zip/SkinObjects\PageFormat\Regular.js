﻿$(function () {

    //Set the Grid layout
    if ((!($("#dnn_RightPane").hasClass("DNNEmptyPane")) && ($("#dnn_LeftPane").hasClass("DNNEmptyPane"))) || (($("#dnn_RightPane").hasClass("DNNEmptyPane")) && !($("#dnn_LeftPane").hasClass("DNNEmptyPane")))) {
        $("#dnn_ContentPane").removeClass("span-6");
        $("#dnn_ContentPane").addClass("span-9");
    }
    else if (($("#dnn_RightPane").hasClass("DNNEmptyPane")) && ($("#dnn_LeftPane").hasClass("DNNEmptyPane"))) {
        $("#dnn_ContentPane").removeClass("span-6");
        $("#dnn_ContentPane").addClass("span-12");
    }

    if (!($("#dnn_MediaPane").hasClass("DNNEmptyPane"))) {
        $("#dnn_MediaPane").addClass("span-12");
    }

});

