﻿Imports DotNetNuke.Entities.Tabs

Partial Class Portals__default_Skins_CLF3___DNN6_Skin_Objects_Menu
    Inherits DotNetNuke.UI.Skins.SkinObjectBase

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Try
            GetPages() ' Main menu
            lblMenu.Text = "<div><ul class='mb-menu'>" & lblMenu.Text & "</ul></div>"
            'Response.Write(HttpUtility.HtmlEncode(Menu))
        Catch ex As Exception
            If PortalSettings.UserInfo.IsSuperUser Then lblMenu.Text = ex.Message
        End Try
    End Sub

    Protected Sub GetPages()
        Try
            'Variables
            Dim LastTab As New TabInfo
            Dim RootTab As New TabInfo
            Dim MainPage As String = Localization.GetString("SKINMenuMain.Text", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" + System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc))) & " - "
            Dim HiddenTabs As String = "@"
            Dim PageURL As String = "#"
            Dim Menu As String = ""
            Dim FirstRun As Boolean = True
            Dim RootURL As String = ""

            'Templates
            Dim TEMPLATERootEmpty As String = "<li><div>[LINK]</div></li>"
            Dim TEMPLATERootSub As String = "<li><section><h3>[LINK]</h3><div class='mb-sm'>[LEVEL1FOCUS][LEVEL1SUB]<div class='clear'></div><div class='mb-main-link'>[MAINLINK]</div></div></section></li>"
            Dim TEMPLATESecondLevelFocus As String = "<div class='mb-highlight'><section><h4><a href='#'>" & Localization.GetString("SKINMenuFocus.Text", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc))) & "</a></h4><ul>[FOCUS]</ul><div class='clear'></div></section></div>"
            Dim TEMPLATESecondLevel As String = "<div class='span-2'><section><h4>[SECONDLEVELLINK]</h4><ul>[SUBLIST]</ul></section></div>"

            'Hold the temporary lists
            Dim ULSecondLevelFocus As String = ""
            Dim ULSecondLevel As String = ""

            'Check Languages
            Dim TC As New TabController
            Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name
            Dim LC As New LocaleController
            Dim DefaultLocale As String = LC.GetDefaultLocale(PortalSettings.PortalId).Code

            'Get list of pages
            For Each T As TabInfo In TabController.GetPortalTabs(PortalSettings.PortalId, -1, False, "", True, False, True, True, True)

                If T.Level <= 2 Then

                    'List of pages not to show in the menu
                    If T.IsVisible = False Or HiddenTabs.Contains("@" & T.ParentId & "@") Then
                        HiddenTabs = HiddenTabs & T.TabID & "@"
                    End If

                    'Check if the tab has a hidden parent
                    If HiddenTabs.Contains("@" & T.TabID & "@") = False Then

                        If FirstRun = False Then
                            'Level 2 Menu
                            If LastTab.Level = 2 Then
                                ULSecondLevel = ULSecondLevel & "<li>" & PageURL & "</li>"
                            End If

                            'Level 1 Menu 
                            If LastTab.Level = 1 And T.Level <= 1 Then
                                ULSecondLevelFocus = ULSecondLevelFocus & "<li>" & PageURL & "</li>"
                            ElseIf T.Level = 2 And LastTab.Level = 1 Then
                                Menu = Menu.Replace("[LEVEL1SUB]", TEMPLATESecondLevel & "[LEVEL1SUB]")
                                Menu = Menu.Replace("[SECONDLEVELLINK]", PageURL)
                            ElseIf T.Level <> 2 And LastTab.Level = 2 Then
                                Menu = Menu.Replace("[SUBLIST]", ULSecondLevel)
                                ULSecondLevel = ""
                            End If

                            'Menu Root 
                            If T.Level = 0 And LastTab.Level = 0 Then
                                Menu = Menu & TEMPLATERootEmpty.Replace("[LINK]", RootURL)
                            ElseIf T.Level > 0 And LastTab.Level = 0 Then
                                Menu = Menu & TEMPLATERootSub
                                Menu = Menu.Replace("[LINK]", RootURL)
                                Menu = Menu.Replace("[MAINLINK]", RootURL.Replace("'>", "'>" & MainPage))
                            End If

                            If T.Level = 0 Then
                                If ULSecondLevelFocus <> "" then
                                    Menu = Menu.Replace("[LEVEL1FOCUS]", TEMPLATESecondLevelFocus)
                                    Menu = Menu.Replace("[FOCUS]", ULSecondLevelFocus)
                                End If
                                ULSecondLevelFocus = ""
                                Menu = Menu.Replace("[LEVEL1FOCUS]", "")
                            End If
                        Else
                            FirstRun = False
                        End If

                        'Set Other Locale
                        Dim MainTitle As String = T.TabName
                        If DefaultLocale <> ThisLocale Then
                            Dim hash As Hashtable = TC.GetTabSettings(T.TabID)
                            If String.IsNullOrEmpty(hash("PageTitle" & ThisLocale)) = False Then
                                MainTitle = hash("PageTitle" & ThisLocale).ToString
                            End If
                        End If
                        'Disable Link
                        If T.DisableLink Then
                            PageURL = "<a href='#'>" & MainTitle & "</a>"
                        Else
                            PageURL = "<a href='" & T.FullUrl.ToLower.Replace("en-ca/", "").Replace("en-us/", "").Replace("fr-ca/", "") & "'>" & MainTitle & "</a>"
                        End If


                        If T.Level = 0 Then
                            'Set the root tab information
                            RootTab = New TabInfo
                            RootTab = T
                            RootURL = PageURL
                            Menu = Menu.Replace("[LEVEL1SUB]", "")
                        End If

                        'Update last tab value
                        LastTab = New TabInfo
                        LastTab = T

                    End If

                End If

            Next

            If HiddenTabs.Contains("@" & LastTab.ParentId & "@") = False Then
                'Level 2 Menu
                If LastTab.Level = 2 Then
                    ULSecondLevel = ULSecondLevel & "<li>" & PageURL & "</li>"
                    Menu = Menu.Replace("[LEVEL1SUB]", TEMPLATESecondLevel)
                    Menu = Menu.Replace("[SECONDLEVELLINK]", PageURL)
                    Menu = Menu.Replace("[SUBLIST]", ULSecondLevel)
                End If

                'Level 1 Menu 
                If LastTab.Level = 1 Then
                    ULSecondLevelFocus = ULSecondLevelFocus & "<li>" & PageURL & "</li>"
                End If

                'Menu Root 
                If LastTab.Level = 0 Then
                    Menu = Menu & TEMPLATERootEmpty.Replace("[LINK]", RootURL)
                End If

                If ULSecondLevelFocus <> "" Then
                    Menu = Menu.Replace("[LEVEL1FOCUS]", TEMPLATESecondLevelFocus)
                    Menu = Menu.Replace("[FOCUS]", ULSecondLevelFocus)
                End If
            End If

            'Clear anything left in the menu code
            Menu = Menu.Replace("[LEVEL1FOCUS]", "")
            Menu = Menu.Replace("[LEVEL1SUB]", "")

            lblMenu.Text = Menu
        Catch ex As Exception
            If PortalSettings.UserInfo.IsSuperUser Then lblMenu.Text = ex.Message
        End Try
    End Sub

End Class
