﻿Imports DotNetNuke.Entities.Tabs
Partial Class Portals__default_Skins_CLF3_SkinObjects_LeftMenu
    Inherits DotNetNuke.UI.Skins.SkinObjectBase

    'Check Languages
    Dim TC As New TabController
    Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name
    Dim LC As New LocaleController
    Dim DefaultLocale As String = LC.GetDefaultLocale(PortalSettings.PortalId).Code

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        Dim hash As Hashtable = TC.GetTabSettings(PortalSettings.ActiveTab.TabID)

        If PortalSettings.ActiveTab.TabID = PortalSettings.HomeTabId Then
            pnlShowMenu.Visible = False
        ElseIf String.IsNullOrEmpty(hash("ShowLeftMenu")) Then
            pnlShowMenu.Visible = True
        Else
            pnlShowMenu.Visible = hash("ShowLeftMenu")
        End If

        If ltlMenu.Text = "" And pnlShowMenu.Visible Then

            Dim Level1Tab As New TabInfo
            Dim TopLevel As Integer = 3

            'Get level 1 tab for current section
            Level1Tab = PortalSettings.ActiveTab
            While Level1Tab.Level > 1
                Level1Tab = TC.GetTab(Level1Tab.ParentId, PortalSettings.PortalId, False) 'Using Cache
            End While
            TopLevel = 2

            LoadMenu(Level1Tab.TabID, TopLevel)
            SetLocalization()
        End If

    End Sub

    Protected Sub SetLocalization()
        pnlOutdated.ToolTip = Localization.GetString("SKINOutdated", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        btnOutdated.Text = Localization.GetString("SKINSubmit", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        lblOutOfDate.Text = Localization.GetString("SKINReasonOutOfDate", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
    End Sub

    Protected Sub LoadMenu(ByVal ParentID As Integer, ByVal TopLevel As Integer)
        Try
            Dim NavCurrent As String = ""

            Dim ParentTab As TabInfo = TC.GetTab(ParentID, PortalSettings.PortalId, False)
            Dim ParentName As String = ParentTab.TabName
            'Grab the other language if one exists
            If DefaultLocale <> ThisLocale Then
                Dim hash As Hashtable = TC.GetTabSettings(ParentID)
                If String.IsNullOrEmpty(hash("PageTitle" & ThisLocale)) = False Then
                    ParentName = hash("PageTitle" & ThisLocale).ToString
                End If
            End If
            If ParentTab.TabID = PortalSettings.ActiveTab.TabID Then NavCurrent = "class='nav-current' "
            If ParentTab.DisableLink Then
                ltlMenu.Text = "<li class='top-level'><a " & NavCurrent & "href='#'>" & ParentName & "</a></li>"
            Else
                ltlMenu.Text = "<li class='top-level'><a " & NavCurrent & "href='" & ParentTab.FullUrl.ToLower.Replace(System.Globalization.CultureInfo.CurrentUICulture.Name.ToLower + "/", "") & "'>" & ParentName & "</a></li>"
            End If

            For Each T As TabInfo In TabController.GetTabsByParent(ParentID, PortalSettings.PortalId)
                Dim TabName As String
                TabName = T.TabName
                NavCurrent = ""
                If T.TabID = PortalSettings.ActiveTab.TabID Then NavCurrent = "class='nav-current' "

                'Grab the other language if one exists
                If DefaultLocale <> ThisLocale Then
                    Dim hash As Hashtable = TC.GetTabSettings(T.TabID)
                    If String.IsNullOrEmpty(hash("PageTitle" & ThisLocale)) = False Then
                        TabName = hash("PageTitle" & ThisLocale).ToString
                    End If
                End If

                If T.IsVisible And T.IsDeleted = False Then
                    If PortalSecurity.IsInRoles(T.AuthorizedRoles) Then
                        If T.DisableLink Then
                            ltlMenu.Text = ltlMenu.Text & "<li><a " & NavCurrent & "href='#'>" & TabName & "</a></li>"
                        Else
                            ltlMenu.Text = ltlMenu.Text & "<li><a " & NavCurrent & "href='" & T.FullUrl.ToLower.Replace(System.Globalization.CultureInfo.CurrentUICulture.Name.ToLower + "/", "") & "'>" & TabName & "</a></li>"
                        End If
                    End If
                End If
            Next

        Catch ex As Exception
            If PortalSettings.UserInfo.IsSuperUser Then ltlMenu.Text = ex.Message
        End Try


    End Sub

    Protected Sub btnOutdated_Click(sender As Object, e As System.EventArgs) Handles btnOutdated.Click
        Try
            Dim SendTo, SendFrom, MsgTitle, MsgBody As String

            'Send From Email
            If PortalSettings.UserInfo.UserID > 0 Then
                SendFrom = PortalSettings.UserInfo.Email
            Else
                SendFrom = PortalSettings.Email
            End If

            'Send To Email
            Dim PageOwner As DotNetNuke.Entities.Users.UserInfo
            PageOwner = PortalSettings.ActiveTab.CreatedByUser(PortalSettings.PortalId)

            If PageOwner Is Nothing = False Then
                If PageOwner.IsDeleted = False And String.IsNullOrEmpty(PageOwner.Email) = False Then
                    SendTo = PageOwner.Email
                Else
                    SendTo = PortalSettings.Email
                End If
            Else
                SendTo = PortalSettings.Email
            End If

            'Message Title
            MsgTitle = Localization.GetString("SKINMessageTitle", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
            MsgTitle = MsgTitle & PortalSettings.ActiveTab.TabName

            'Message Body
            MsgBody = Localization.GetString("SKINMessageBody", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
            If txtOutOfDate.Text.Trim <> "" Then MsgBody = txtOutOfDate.Text & "<br /><br />" & MsgBody
            MsgBody = MsgBody & "<a href='" & PortalSettings.ActiveTab.FullUrl.ToLower.Replace(System.Globalization.CultureInfo.CurrentUICulture.Name.ToLower + "/", "") & "'>" & PortalSettings.ActiveTab.FullUrl.ToLower.Replace(System.Globalization.CultureInfo.CurrentUICulture.Name.ToLower + "/", "") & "</a>"

            DotNetNuke.Services.Mail.Mail.SendEmail(SendFrom, SendTo, MsgTitle, MsgBody)

        Catch ex As Exception
            If PortalSettings.UserInfo.IsSuperUser Then ltlMenu.Text = ex.Message
        End Try
    End Sub
End Class
