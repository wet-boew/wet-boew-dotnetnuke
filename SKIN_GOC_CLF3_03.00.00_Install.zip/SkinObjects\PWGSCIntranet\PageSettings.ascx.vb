﻿Imports DotNetNuke

Partial Class Portals__default_Skins_CLF3_SkinObjects_PWGSCIntranet_PageSettings
    Inherits DotNetNuke.UI.Skins.SkinObjectBase

    Dim TC As New DotNetNuke.Entities.Tabs.TabController
    Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name
    Dim LC As New LocaleController
    Dim DefaultLocale As String = LC.GetDefaultLocale(PortalSettings.PortalId).Code

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Try
            If Page.IsPostBack = False Then
                'Use the tab settings
                Dim hash As Hashtable = TC.GetTabSettings(PortalSettings.ActiveTab.TabID)

                'Page Heading, multilingual
                If String.IsNullOrEmpty(hash("PageHeading" & ThisLocale)) Then
                    ltlHeading.Text = PortalSettings.ActiveTab.TabName
                Else
                    ltlHeading.Text = hash("PageHeading" & ThisLocale).ToString
                End If
                txtHeading.Text = ltlHeading.Text

                'Default Toggle Left Menu
                If String.IsNullOrEmpty(hash("ShowLeftMenu")) Then
                    TC.UpdateTabSetting(PortalSettings.ActiveTab.TabID, "ShowLeftMenu", "True")
                End If
            End If

            btnToggleLeftMenu.Visible = PortalSettings.UserInfo.IsInRole("Administrators")
            pnlSettings.Visible = IsEditMode()
            btnToggleLeftMenu.Text = Localization.GetString("SKINToggleMenu", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
            btnSaveHeading.Text = Localization.GetString("SKINSaveHeading", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
        Catch ex As Exception
            If PortalSettings.UserInfo.IsSuperUser Then Response.Write("Page Settings: " & ex.Message)
        End Try
    End Sub

    Protected Sub btnSaveHeading_Click(sender As Object, e As System.EventArgs) Handles btnSaveHeading.Click
        TC.UpdateTabSetting(PortalSettings.ActiveTab.TabID, "PageHeading" & ThisLocale, txtHeading.Text)
        ltlHeading.Text = txtHeading.Text
    End Sub

    Protected Sub btnToggleLeftMenu_Click(sender As Object, e As System.EventArgs) Handles btnToggleLeftMenu.Click
        Dim hash As Hashtable = TC.GetTabSettings(PortalSettings.ActiveTab.TabID)

        If hash("ShowLeftMenu").ToString = "True" Then
            TC.UpdateTabSetting(PortalSettings.ActiveTab.TabID, "ShowLeftMenu", "False")
        Else
            TC.UpdateTabSetting(PortalSettings.ActiveTab.TabID, "ShowLeftMenu", "True")
        End If

        Response.Redirect(PortalSettings.ActiveTab.FullUrl.ToLower.Replace(System.Globalization.CultureInfo.CurrentUICulture.Name.ToLower + "/", ""))
    End Sub
End Class
