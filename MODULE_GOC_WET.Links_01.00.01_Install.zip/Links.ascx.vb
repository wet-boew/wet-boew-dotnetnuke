﻿
Partial Class DesktopModules_WET_Links_Links
    Inherits DotNetNuke.Entities.Modules.PortalModuleBase

    Protected Sub ListWrapper()
        If ModuleConfiguration.DisplayTitle = False And IsEditable = False Then
            Dim listclass As String = "class='module-table-contents'"
            If ModuleConfiguration.PaneName.ToUpper = "LEFTPANE" Then
                listclass = "class='wb-sec-def'"
            ElseIf ModuleConfiguration.PaneName.ToUpper = "RIGHTPANE" Then
                listclass = "class='module-menu-section'"
            End If
            ltlList.Text = "<div " & listclass & "> <h4 style='display:none'></h4>" & ltlList.Text
            ltlList.Text = ltlList.Text & "</div>"
        End If
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Try

            If Page.IsPostBack = False Then
                LoadList()
                ListWrapper()

                If IsEditable Then
                    pnlAdmin.ToolTip = Localization.GetString("titleAdmin", Me.LocalResourceFile)
                    pnlEdit.ToolTip = Localization.GetString("titleAdmin", Me.LocalResourceFile)
                    cbxLanguages.Text = Localization.GetString("cbxLanguages", Me.LocalResourceFile)
                End If
            End If
            pnlAdminBtn.Visible = IsEditable
        Catch ex As Exception
            DotNetNuke.Services.Exceptions.LogException(ex)
            If UserInfo.IsSuperUser Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, ex.Message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("msgError.Text", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If
        End Try
    End Sub

    Protected Sub LoadList()
        ltlList.Text = ""
        Dim ConnString As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
        ConnString.Open()

        Dim WETCommand As New SqlCommand
        WETCommand.CommandText = "SELECT * FROM WET_List WHERE ModuleId = @ModuleID ORDER BY [ListOrder]"
        WETCommand.Parameters.AddWithValue("@ModuleID", ModuleId)
        WETCommand.Connection = ConnString

        Dim reader As SqlDataReader = WETCommand.ExecuteReader

        Try
            If reader.HasRows Then
                While reader.Read
                    ltlList.Text = ltlList.Text & "<li>"
                    Dim Link, Title As String
                    If System.Globalization.CultureInfo.CurrentUICulture.Name.ToLower.StartsWith("en") Then
                        Link = reader.Item("EnglishLink").ToString
                        Title = reader.Item("EnglishName").ToString
                    Else
                        Link = reader.Item("FrenchLink").ToString
                        Title = reader.Item("FrenchName").ToString
                    End If
                    If Link <> "" Then
                        ltlList.Text = ltlList.Text & "<a href='" & Link & "' title='" & Title & "'>" & Title & "</a>"
                    Else
                        ltlList.Text = ltlList.Text & "<a>" & Title & "</a>"
                    End If
                    ltlList.Text = ltlList.Text & "</li>"
                End While
                ltlList.Text = "<ul>" & ltlList.Text & "</ul>"
            End If

            If IsEditable Then
                ConnString.Close()
                ConnString.Open()
                grdList.DataSource = WETCommand.ExecuteReader
                grdList.DataBind()
            End If

        Catch ex As Exception
            DotNetNuke.Services.Exceptions.LogException(ex)
        Finally
            ConnString.Close()
        End Try
    End Sub

    Protected Sub btnSave_Click(sender As Object, e As System.EventArgs) Handles btnSave.Click
        Try
            Dim ConnString As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
            ConnString.Open()

            Dim WETCommand As New SqlCommand
            WETCommand.CommandText = "INSERT INTO WET_List(EnglishName, FrenchName, EnglishLink, FrenchLink, ListOrder, Clicks, ModuleID) VALUES(@EnglishName, @FrenchName, @EnglishLink, @FrenchLink, ISNULL((SELECT Top 1 ListOrder FROM WET_List WHERE ModuleID = @ModuleID Order By ListOrder Desc),0) + 1, 0, @ModuleID)"
            WETCommand.Parameters.AddWithValue("@ModuleID", ModuleId)

            If String.IsNullOrEmpty(txtFrenchLink.Text) Then txtFrenchLink.Text = txtEnglishLink.Text
            If String.IsNullOrEmpty(txtEnglishLink.Text) Then txtEnglishLink.Text = txtFrenchLink.Text
            If String.IsNullOrEmpty(txtFrenchTitle.Text) Then txtFrenchTitle.Text = txtEnglishTitle.Text
            If String.IsNullOrEmpty(txtEnglishTitle.Text) Then txtEnglishTitle.Text = txtFrenchTitle.Text

            WETCommand.Parameters.AddWithValue("@EnglishName", txtEnglishTitle.Text)
            WETCommand.Parameters.AddWithValue("@FrenchName", txtFrenchTitle.Text)
            WETCommand.Parameters.AddWithValue("@EnglishLink", txtEnglishLink.Text)
            WETCommand.Parameters.AddWithValue("@FrenchLink", txtFrenchLink.Text)

            WETCommand.Connection = ConnString
            Try
                WETCommand.ExecuteNonQuery()
            Catch ex As Exception
                DotNetNuke.Services.Exceptions.LogException(ex)
                If UserInfo.IsSuperUser Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, ex.Message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("msgError.Text", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                End If
            Finally
                ConnString.Close()
            End Try

            txtFrenchLink.Text = ""
            txtFrenchTitle.Text = ""
            txtEnglishLink.Text = ""
            txtEnglishTitle.Text = ""
            LoadList()
        Catch ex As Exception
            DotNetNuke.Services.Exceptions.LogException(ex)
            If UserInfo.IsSuperUser Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, ex.Message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("msgError.Text", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If
        End Try
    End Sub

    Protected Sub grdList_RowDeleting(sender As Object, e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grdList.RowDeleting
        Dim ConnString As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
        ConnString.Open()

        Dim WETCommand As New SqlCommand
        WETCommand.CommandText = "DELETE FROM WET_List WHERE ID = @ID"
        WETCommand.Parameters.AddWithValue("@ID", grdList.Rows(e.RowIndex).Cells(0).Text)
        WETCommand.Connection = ConnString
        Try
            WETCommand.ExecuteNonQuery()
            LoadList()
        Catch ex As Exception
            DotNetNuke.Services.Exceptions.LogException(ex)
            If UserInfo.IsSuperUser Then
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, ex.Message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("msgError.Text", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If
        Finally
            ConnString.Close()
        End Try
    End Sub

    Protected Sub btnUpdate_Click(sender As Object, e As System.EventArgs) Handles btnUpdate.Click
        For Each row As GridViewRow In grdList.Rows
            Try
                Dim ConnString As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("SiteSqlServer").ToString)
                ConnString.Open()

                Dim WETCommand As New SqlCommand
                WETCommand.CommandText = "UPDATE WET_List SET EnglishName = @EnglishName, FrenchName = @FrenchName, EnglishLink = @EnglishLink, FrenchLink = @FrenchLink, ListOrder = @Order WHERE ID = @ID"

                If CType(row.FindControl("txtEngLink"), TextBox).Text.Trim = "" Then CType(row.FindControl("txtEngLink"), TextBox).Text = CType(row.FindControl("txtFraLink"), TextBox).Text
                If CType(row.FindControl("txtFraLink"), TextBox).Text.Trim = "" Then CType(row.FindControl("txtFraLink"), TextBox).Text = CType(row.FindControl("txtEngLink"), TextBox).Text
                If CType(row.FindControl("txtEngName"), TextBox).Text.Trim = "" Then CType(row.FindControl("txtEngName"), TextBox).Text = CType(row.FindControl("txtFraName"), TextBox).Text
                If CType(row.FindControl("txtFraName"), TextBox).Text.Trim = "" Then CType(row.FindControl("txtFraName"), TextBox).Text = CType(row.FindControl("txtEngName"), TextBox).Text
                If CType(row.FindControl("txtOrder"), TextBox).Text.Trim = "" Then CType(row.FindControl("txtOrder"), TextBox).Text = "0"
                If IsNumeric(CType(row.FindControl("txtOrder"), TextBox).Text) = False Then CType(row.FindControl("txtOrder"), TextBox).Text = "0"

                WETCommand.Parameters.AddWithValue("@EnglishName", CType(row.FindControl("txtEngName"), TextBox).Text)
                WETCommand.Parameters.AddWithValue("@FrenchName", CType(row.FindControl("txtFraName"), TextBox).Text)
                WETCommand.Parameters.AddWithValue("@EnglishLink", CType(row.FindControl("txtEngLink"), TextBox).Text)
                WETCommand.Parameters.AddWithValue("@FrenchLink", CType(row.FindControl("txtFraLink"), TextBox).Text)
                WETCommand.Parameters.AddWithValue("@Order", CType(row.FindControl("txtOrder"), TextBox).Text)
                WETCommand.Parameters.AddWithValue("@ID", row.Cells(0).Text)

                WETCommand.Connection = ConnString
                Try
                    WETCommand.ExecuteNonQuery()
                Catch ex As Exception
                    DotNetNuke.Services.Exceptions.LogException(ex)
                    If UserInfo.IsSuperUser Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, ex.Message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("msgError.Text", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    End If
                Finally
                    ConnString.Close()
                End Try

                LoadList()
            Catch ex As Exception
                DotNetNuke.Services.Exceptions.LogException(ex)
                If UserInfo.IsSuperUser Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, ex.Message, Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("msgError.Text", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                End If
            End Try
        Next
    End Sub
End Class
