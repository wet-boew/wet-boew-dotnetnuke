﻿
Partial Class DesktopModules_PWGSC_MLHTML_Edit
    Inherits DotNetNuke.Entities.Modules.PortalModuleBase

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        'Populate the HTML
        Try
            Using connection As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("SiteSqlServer").ToString)
                Dim command As New SqlCommand
                'Grab a different version if a different language
                Dim LangController As New LocaleController
                Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name

                'Get the last HTML Text             
                command.CommandText = "SELECT [ItemID],[Content],[Summary] FROM [HtmlText] WHERE ModuleID = @ModuleID ORDER BY LastModifiedOnDate "
                command.Parameters.AddWithValue("@ModuleID", ModuleId)
                command.Connection = connection
                Try
                    command.Connection.Open()
                    Dim reader As SqlDataReader = command.ExecuteReader
                    Dim defaultLocale As String = ""
                    Dim LocaleNotFound As Boolean = True

                    If reader.HasRows Then
                        'Populate the field
                        While reader.Read
                            If reader.Item("Summary").ToString.Trim = ThisLocale.Trim Then
                                LocaleNotFound = False
                                hdnID.Text = reader.Item("ItemID").ToString
                                txtAdminView.Text = HttpUtility.HtmlDecode(reader.Item("Content").ToString)
                            End If
                        End While
                        If LocaleNotFound Then
                            AddHTML()
                        End If
                    Else
                        'No HTML yet, so add one
                        AddHTML()
                    End If

                Finally
                    command.Connection.Close()
                End Try
            End Using
        Catch ex As Exception
            If PortalSettings.UserInfo.IsSuperUser Then txtAdminView.Text = ex.Message
        End Try
    End Sub

    Protected Sub AddHTML()
        'Populate the HTML
        Try
            Using connection As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("SiteSqlServer").ToString)
                Dim command As New SqlCommand
                'Grab a different version if a different language
                Dim LangController As New LocaleController
                Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name

                'Get the last HTML Text             
                command.CommandText = "AddHtmlText"
                command.CommandType = CommandType.StoredProcedure
                command.Parameters.AddWithValue("@ModuleID", ModuleId)
                command.Parameters.AddWithValue("@IsPublished", 1)
                command.Parameters.AddWithValue("@Content", "Edit to enter content..")
                command.Parameters.AddWithValue("@Summary", ThisLocale)
                command.Parameters.AddWithValue("@StateID", 1)
                command.Parameters.AddWithValue("@UserID", UserId)
                command.Parameters.AddWithValue("@History", 0)
                command.Connection = connection
                Try
                    command.Connection.Open()
                    hdnID.Text = command.ExecuteScalar()
                    txtAdminView.Text = ""
                Finally
                    command.Connection.Close()
                End Try
            End Using
        Catch ex As Exception
            If PortalSettings.UserInfo.IsSuperUser Then txtAdminView.Text = ex.Message
        End Try
    End Sub


    Protected Sub BtnSaveContent_Click(sender As Object, e As System.EventArgs) Handles BtnSaveContent.Click
        'Update the HTML
        Try
            Using connection As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("SiteSqlServer").ToString)
                Dim command As New SqlCommand
                'Grab a different version if a different language
                Dim LangController As New LocaleController
                Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name

                'Get the last HTML Text             
                command.CommandText = "UpdateHtmlText"
                command.CommandType = CommandType.StoredProcedure
                command.Parameters.AddWithValue("@ItemID", hdnID.Text)
                command.Parameters.AddWithValue("@IsPublished", 1)
                command.Parameters.AddWithValue("@Content", txtAdminView.Text)
                command.Parameters.AddWithValue("@Summary", ThisLocale)
                command.Parameters.AddWithValue("@StateID", 1)
                command.Parameters.AddWithValue("@UserID", UserId)
                command.Connection = connection
                Try
                    command.Connection.Open()
                    command.ExecuteNonQuery()
                Finally
                    command.Connection.Close()
                End Try
            End Using

            Response.Redirect(NavigateURL(), True)
        Catch ex As Exception
            If PortalSettings.UserInfo.IsSuperUser Then txtAdminView.Text = ex.Message
        End Try
    End Sub

End Class
