﻿Imports DotNetNuke.Entities.Modules

Partial Class DesktopModules_PWGSC_MLHTML_MLHTML
    Inherits DotNetNuke.Entities.Modules.PortalModuleBase
    Implements IActionable

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        'Populate the HTML
        Try
            Using connection As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("SiteSqlServer").ToString)
                Dim command As New SqlCommand
                'Grab a different version if a different language
                Dim LangController As New LocaleController
                Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name

                'Get the last HTML Text             
                command.CommandText = "SELECT [ItemID],[Content],[Summary] FROM [HtmlText] WHERE ModuleID = @ModuleID ORDER BY LastModifiedOnDate "
                command.Parameters.AddWithValue("@ModuleID", ModuleId)
                command.Connection = connection
                Try
                    command.Connection.Open()
                    Dim reader As SqlDataReader = command.ExecuteReader
                    Dim defaultLocale As String = ""
                    Dim LocaleNotFound As Boolean = True

                    lblUserView.Text = "Edit to enter content.."

                    'User View
                    While reader.Read
                        If reader.Item("Summary").ToString.Trim = ThisLocale.Trim Then
                            lblUserView.Text = HttpUtility.HtmlDecode(reader.Item("Content").ToString)
                        End If

                        'Store the default locale incase no locale set for the current one
                        If LangController.GetDefaultLocale(PortalId).Code.Trim = reader.Item("Summary").ToString.Trim Then
                            defaultLocale = reader.Item("Content").ToString
                        End If
                    End While

                    'Load the default locale if it has data but the other doesn't
                    If (String.IsNullOrEmpty(lblUserView.Text) Or lblUserView.Text = "Edit to enter content..") And String.IsNullOrEmpty(defaultLocale) = False Then
                        lblUserView.Text = HttpUtility.HtmlDecode(defaultLocale)
                    End If

                    If lblUserView.Text = "Edit to enter content.." And ThisLocale.ToLower = "fr-ca" Then
                        lblUserView.Text = "Modifier pour entrer le contenu.."
                    End If

                Finally
                    command.Connection.Close()
                End Try
            End Using
        Catch ex As Exception
            If PortalSettings.UserInfo.IsSuperUser Then lblUserView.Text = ex.Message
        End Try
    End Sub

    Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
        Get
            Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
            Actions.Add(GetNextActionID, Localization.GetString("Edit.Text", LocalResourceFile), Entities.Modules.Actions.ModuleActionType.EditContent, "", "", EditUrl("Edit"), False, DotNetNuke.Security.SecurityAccessLevel.Edit, True, False)
            Return Actions
        End Get
    End Property
End Class
