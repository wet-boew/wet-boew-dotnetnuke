﻿Partial Class Portals__default_Skins_CLF_Skin_Skin_Objects_Search
    Inherits DotNetNuke.UI.Skins.SkinObjectBase

End Class
