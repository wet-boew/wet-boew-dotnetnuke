﻿$(function () {

    if ($("#dnn_LeftPane").length == 0) {
        //Set the Grid Layout with a secondary menu
        if ($("#dnn_RightPane").hasClass("DNNEmptyPane")) {
            //Regular Page
            $("#dnn_ContentPane").removeClass("span-9");
            $("#dnn_ContentPane").addClass("span-12");
        }
    }
    else if ($("#dnn_ContentPane").hasClass("span-9") && $("#dnn_RightPane").hasClass("DNNEmptyPane") == false && $("#dnn_LeftPane").length != 0 && $("#dnn_LeftPane").hasClass("DNNEmptyPane") == false) {
            //Homepage on secondary menu layout
            $("#dnn_ContentPane").removeClass("span-9");
            $("#dnn_ContentPane").addClass("span-6");
    }
    else {
        //Set the Grid layout with no secondary menu
        if ((!($("#dnn_RightPane").hasClass("DNNEmptyPane")) && ($("#dnn_LeftPane").hasClass("DNNEmptyPane"))) || (($("#dnn_RightPane").hasClass("DNNEmptyPane")) && !($("#dnn_LeftPane").hasClass("DNNEmptyPane")))) {
            $("#dnn_ContentPane").removeClass("span-6");
            $("#dnn_ContentPane").addClass("span-9");
        }
        else if (($("#dnn_RightPane").hasClass("DNNEmptyPane")) && ($("#dnn_LeftPane").hasClass("DNNEmptyPane"))) {
            $("#dnn_ContentPane").removeClass("span-6");
            $("#dnn_ContentPane").addClass("span-12");
        }

        if (!($("#dnn_MediaPane").hasClass("DNNEmptyPane"))) {
            $("#dnn_MediaPane").addClass("span-12");
        }

    }
});

