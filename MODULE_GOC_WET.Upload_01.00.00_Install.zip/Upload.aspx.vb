﻿Imports System.IO
Imports DotNetNuke.Services.FileSystem

Partial Class Upload
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Try

            Dim fileName As String
            Dim rawFile As Byte()

            Using binaryReader = New BinaryReader(Request.Files(0).InputStream)
                rawFile = binaryReader.ReadBytes(Request.Files(0).ContentLength)
                fileName = Request.Files(0).FileName
            End Using

            'Get DNN Folder Location
            Dim ThisFolder As New FolderInfo
            ThisFolder = FolderManager.Instance.GetFolder(Request.QueryString("Folder").ToString)

            File.WriteAllBytes(Server.MapPath("~/Portals/" & ThisFolder.PortalID & "/" & ThisFolder.FolderPath) & fileName, rawFile)

            Response.Write("{""success"":true}")

        Catch ex As Exception
            Response.Write("{""error"":""" & ex.Message & """}")
        End Try

    End Sub
End Class
