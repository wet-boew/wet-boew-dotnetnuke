﻿Imports DotNetNuke.Services.FileSystem

Partial Class DesktopModules_WET_Upload_Upload
    Inherits DotNetNuke.Entities.Modules.PortalModuleBase

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            LoadDDL()
        End If

        lblAdmin.Visible = UserInfo.IsSuperUser
        lblAdmin.Text = Localization.GetString("lblAdmin.Text", Me.LocalResourceFile).Replace("[CODE]", HttpUtility.HtmlEncode(Localization.GetString("msgCode.Text", Me.LocalResourceFile)))
    End Sub

    Protected Sub LoadDDL()

        Dim DC As New Documents.DocumentController

        For Each Folder As DotNetNuke.Services.FileSystem.FolderInfo In FolderManager.Instance.GetFolders(UserInfo)
            ddlFolder.Items.Add(New ListItem(Folder.FolderPath, Folder.FolderID))
        Next

    End Sub

    Protected Sub ddlFolder_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlFolder.SelectedIndexChanged

    End Sub
End Class
